﻿function fTime {   param( [System.UInt32]$timeHigh, [System.UInt32]$timeLow )
  if ($timeHigh -or $timeLow) {
    [datetime]::FromFileTime((([long]$timeHigh -shl 32) -bor $timeLow)).ToString("yyyy'-'MM'-'dd' 'HH'.'mm'.'ss")
  } else {'0'}
}
function oTime {   param( [PSCustomObject] $o, [string]$tName )
  fTime $o.($tName+'High') $o.($tName+'Low')
}
# PowerShell – Return LastWriteTime Registry Key # http://eddiejackson.net/wp/?p=18374
$Namespace = "ReadRegDate"
Add-Type @"
  using System;  using System.Text;
  using System.Runtime.InteropServices;
  $($Namespace | ForEach-Object { "namespace $_ {" })
  public class advapi32 {
    [DllImport("advapi32.dll", CharSet = CharSet.Auto)]
    public static extern Int32 RegQueryInfoKey(
      Microsoft.Win32.SafeHandles.SafeRegistryHandle hKey,        StringBuilder lpClass,
      [In, Out] ref UInt32 lpcbClass, UInt32 lpReserved,          out UInt32 lpcSubKeys,
      out UInt32 lpcbMaxSubKeyLen,    out UInt32 lpcbMaxClassLen, out UInt32 lpcValues,
      out UInt32 lpcbMaxValueNameLen, out UInt32 lpcbMaxValueLen, out UInt32 lpcbSecurityDescriptor,
      out System.Runtime.InteropServices.ComTypes.FILETIME lpftLastWriteTime
    );
  }
  $($Namespace | ForEach-Object { "}" })
"@
$RegTools = ("$($Namespace -join '.').advapi32") -as [type] # Store the type in a variable
$LastWrite = New-Object System.Runtime.InteropServices.ComTypes.FILETIME # properties that we want returned
#------------------------------

$RegParentPath = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList"
$Profiles = Get-ChildItem -Path Registry::$RegParentPath | 
  foreach {
    $rNm = ($_.Name).Replace('HKEY_LOCAL_MACHINE\' ,'HKLM:\') #; Write-Host -ForegroundColor Magenta $rNm
    $RegKey = Get-Item $rNm #(we will need the handle)
    [void]$RegTools::RegQueryInfoKey($RegKey.Handle, $null, [ref] $null, $null, [ref] $null, [ref] $null, [ref] $null, 
          [ref] $null, [ref] $null, [ref] $null, [ref] $null, [ref] $LastWrite)
    $y = ($LastWrite.dwHighDateTime, $LastWrite.dwLowDateTime) | foreach { [System.BitConverter]::ToUInt32([System.BitConverter]::GetBytes($_), 0) }
    $LastWriteTime = fTime @y

    $a = $_ | Get-ItemProperty

    foreach ($tName in 'LocalProfileLoadTime', 'LocalProfileUnloadTime', 'ProfileAttemptedProfileDownloadTime', 'ProfileLoadTime'){
      if( $null -ne $a.($tName+'Low') ) { # exists ...TimeLow
        $a | Add-Member @{$tName=(oTime $a $tName)}
        $a.psobject.properties.remove($tName+'High')
        $a.psobject.properties.remove($tName+'Low')
      }
    }
    $a | Add-Member @{LastWriteTime=$LastWriteTime}
    $a        
}

$ProfileImagePathList = @() #;$ProfileImagePathList += 'C:\Windows\ServiceProfiles\NetworkService' #-test non-unique
$ProfileImagePathDUPLICATED = @()

Write-Host "`n  " $RegParentPath "`n" -ForegroundColor Cyan
$Profiles | foreach{
  Write-Host $_.PSChildName  -ForegroundColor Magenta
  Write-Host 'LastWriteTime:' $_.LastWriteTime

  if ($_.ProfileImagePath -in $ProfileImagePathList) {
    $ProfileImagePathDUPLICATED += $_.ProfileImagePath
    $color="Red"
  } Else {$color="White"}
  Write-Host ($_ | Format-List | Out-String) -ForegroundColor $color
  $ProfileImagePathList += $_.ProfileImagePath
}
Write-Host 'ProfileImagePath_List:'
Write-Host ($ProfileImagePathList | Format-Table | Out-String)
Write-Host 'ProfileImagePathDUPLICATED:'
if ($ProfileImagePathDUPLICATED) {
  Write-Host ($ProfileImagePathDUPLICATED | Format-Table | Out-String) -ForegroundColor "Red"
} else {Write-Host "All profiles are unique" -ForegroundColor "Cyan"}