﻿
$phoneCameraFolder = @{ # nazwę aparatu i właściwy folder DCIM należy odczytać w eksploratorze Windows
  'A40'  = '\Card\DCIM\Camera'
  'Mi 9T'= '\Wewnętrzna pamięć współdzielona\DCIM\Camera'
}
$phonePostfix = @{ #dopisek tuż przed rozszerzeniem nazwy pliku
  'A40'  = '_a'
  'Mi 9T'= ''
}
$tmp='.tmp' 
# - tymczasowe miejsce kopiowania z aparatu (względem folderu skryptu)
# - powinno to być na tym samym dysku co Obrazy i Wideo
            # poniżej podwójne tablice $iv = 0..1 dla _img, _vid
$filterImgVid=@( '(.jpg)|(.jpeg)|(.png)|(.heic)|(.heif)$',
                 '(.mp4)|(.mpeg)|(.mpg)|(.hevc)$' )
<#
1. Kopiowanie plików z DCIM na podstawie nazwy z pominiętymi początkowymi nie-cyframi, 
która jest większa od maksymalnej takiej nazwy ostatnio skopiowanej - zapamiętanej w pliku json.
Tu nie jest ważne co zawierają ciągi cyfr - ważne, żeby nowsze pliki dawały wyższą wartość podczas 
porównywania łańcuchów znaków.
2. Pliki z DCIM są kopiowane do foldera ".tmp". Tam można także wrzucić ręcznie jakieś pliki.
3. Zakładamy, że ciąg cyfr w nazwie w DCIM- pomijając wszelkie nie-cyfry - zawiera yyyyMMddhhmmss...
Będzie to generowało nazwę pliku "yyyy-MM-dd_hh.mm.ss...", gdzie w "..." będzie zachowana 
oryginalna końcówka nazwy oryginalnej, np. "_1_HDR.jpg".  
Jeśli nie ma takich cyfr, to pobierana jest data modyfikacji, a gdy i jej brak to data aktualna.
4. Zdjęcia są docelowo kopiowane do biblioteki "Obrazy" do foldera "yyyy\yyyy-MM-dd".  
Filmy są kopiowane do biblioteki "Wideo" do foldera "yyyy\yyyy-MM".
5. Gdyby plik docelowy o wygenerowanej nazwie "yyyy-MM-dd_hh.mm.ss..." już istniał, to 
   - jeśli ma różną treść, dopisywana jest "_<liczba>" poczynając od "_7" w górę. 
   - jeśli oba są o identycznej treści, to kopiowanie jest pomijane:
     - wstępnie sprawdzany jest rozmiar w px i wielkość w bajtach itp.
     - jeśli te są identyczne, to plik nie jest kopiowany, a na końcu, po porównaniu
       binarnym jest usuwany z ".tmp". Na koniec folder ".tmp" powinien być pusty.
6. Działania osobno dla _img i _vid (w kodzie źródłowym indeksy $iv = 0..1). 
Zob. tez dane konf. na początku skryptu.
#>
# URUCHAMIANIE:
# powershell.exe -noexit -File "importCameraRoll.ps1"
# Można sobie zrobić na pulpicie skrót z takim poleceniem w polu "Element docelowy:" i z "Rozpocznij w:" <_folder, w krórym jest skrypt_>. Warto też dobrać stosowną nazwę i ikonkę tego skrótu.

# Literatura:
# https://stackoverflow.com/questions/55628092/how-to-reliably-copy-items-with-powershell-to-an-mtp-device
# https://plusontech.com/2019/01/05/weekend-powershell-script-copy-files-from-phone-camera-by-month/
# https://blog.daiyanyingyu.uk/2018/03/20/powershell-mtp/
                 
Set-StrictMode -Version 3
$ErrorActionPreference = "Stop" 
$PSDefaultParameterValues['Out-File:Encoding'] = 'utf8'
Add-Type -AssemblyName System.Windows.Forms

$filterMultim=$filterImgVid[0].replace('$','|') + $filterImgVid[1]
$FileList = @([System.Collections.ArrayList]@(), [System.Collections.ArrayList]@()) # ArrayList img vid - lista plików odczytanych z aparatu
$category = @('_img', '_vid')
$DuplicateList = @{} # lista plików, które prawdopodobnie są zdublowane - zalegają w .tmp; klucz:nazwa pliku, wartość: nawzwa docelowa
$tmpPath = "$($pwd.Path)\$tmp\"; if (!(Test-Path $tmpPath)) {New-Item -ItemType Directory -Force -Path $tmpPath}

# https://docs.microsoft.com/en-us/dotnet/api/system.environment.specialfolder?view=netcore-3.1
# $Shell = New-Object -ComObject Shell.Application; 0..62 | foreach {$i=$Shell.NameSpace($_); "$_`t'$($i.Title)'`t$($i.self.Path)"}
$MyComputer = 17
$MyPictures = 39
$MyVideos = 14

            # dla każdego aparatu będzie pamiętany ostatnio odczytany plik obrazu o filmu o najwyższej dacie (a raczej nazwie)
$lastImport= @{ 'lastPhone' = '' };
foreach($n in $phoneCameraFolder.Keys) {
  foreach($e in $category) { $lastImport[$n+$e] = '' }
}  #;'$lastImport.::';$lastImport;''
$lastImport = [PSCustomObject]$lastImport
$lastImportJson = 'lastImport.json' # w folderze skryptu
if (Test-Path $lastImportJson -PathType leaf) {
  $lastImport = (Get-Content -Path $lastImportJson) | ConvertFrom-Json
} #;'$lastImport.:.';$lastImport;'';exit

############### Odczyt listy plików z aparatu ###############
$Shell = New-Object -ComObject Shell.Application
$ShellItem = $Shell.NameSpace($MyComputer)
foreach ( $p in $phoneCameraFolder.Keys) { # wyszukanie podłączonego aparatu
  $phone=($ShellItem.Self.GetFolder.Items()) | where Name -eq $p
  if ( $phone ) {"$p"; break} <#> else {"to nie jest: $p"} <##>
}
$readPhone = 1
if (!($phone)) {
  $tit = 'UWAGA!'
  $msg=@" 
Raczej podłącz telefon
i ponownie uruchom import zdjęć.
Czy chcesz kontynuować bez telefonu?
"@
  if ('Yes' -eq [System.Windows.Forms.MessageBox]::Show($msg, $tit, 'YesNo', 'Warning') ) {
    "
Pomijam czytanie z telefonu, zajmę się plikami w .tmp
"
    $readPhone = 0
  } else {exit}
}
if ($readPhone) {
  "$($phone.Name) -> $($phoneCameraFolder[$phone.Name])"
  $lastImportOld = 0..1 | foreach { $lastImport.($phone.Name+$category[$_]) } # deep copy
  $imgNameMax = $lastImportOld | foreach { $_ } # deep copy for flat array
  $Lp = 0; 
  $tmpFolder = $Shell.NameSpace($tmpPath).self.GetFolder()
  $phoneFolder=$Shell.NameSpace((Join-path $phone.Path  $phoneCameraFolder[$phone.Name]))#.self.GetFolder()

  $items = @( $phoneFolder.Items() | where { ($_.Name -match $filterMultim) } )
  "
Liczba wszystkich plików w DCIM: $($items.Length)
"
  foreach( $item in $items )
  {
    $FName = $item.Name
    $iv = 0; while ( ($iv -lt 2) -and (!($FName -match $filterImgVid[$iv])) ) { $iv++ }
    <##>"+++++ $FName +++++ "<##> 
    if ($iv -lt 2) { # gdy nie to pomijamy plik - ani _img ani _vid (tu niemożliwe)
      # podczas porównania nowości nazwy pliku ignoruję początkowe nie-cyfry
      $imgName1 = $FName -replace '^\D*'; <#>"------------: $imgName1"<##> 
      if ($imgName1 -gt $lastImportOld[$iv]) { 
        if ($imgName1 -gt $imgNameMax[$iv]) {$imgNameMax[$iv] = $imgName1}
        $Lp++; "$($Lp.ToString('000')) ~ $($FName) ($imgName1)"
        [void]$FileList[$iv].Add($FName)
        
        $tmpFolder.CopyHere($item) #=copy (albo MoveHere() - lepiej nie)
      }
    } 
  }
  for ($iv = 0; $iv -lt 2 ; $iv++) {
    if ($imgNameMax[$iv]) { $lastImport.($phone.Name+$category[$iv]) = $imgNameMax[$iv] }
  }
  $lastImport.lastPhone = $phone.Name
  $lastImport | ConvertTo-Json | Set-Content -Path $lastImportJson  <##>
} # if ($readPhone DCIM -> $tmpFolder)

if (! ($FileList[0].Count+$FileList[1].Count)) { # tzn. nie był podłączony tel. - biorę wcześniej podł. tel. i listę plików z dysku
  $phone = [PSCustomObject]@{Name=$lastImport.lastPhone}
  $phone.Name
  foreach( $item in Get-ChildItem -Path $tmpPath ) {
     for ($iv = 0; $iv -lt 2 ; $iv++) {
      if ($item.Name -match $filterImgVid[$iv]) { [void]$FileList[$iv].Add($item.Name) } #_img _vid
    }
  }
  $tmpFolder = $Shell.NameSpace($tmpPath).self.GetFolder()
} # ; '$FileList';  $FileList 

############### Przeniesienie plików do Obrazy i Wideo ###############
"
Nowe pliki img: $($FileList[0].Count)
Nowe pliki vid: $($FileList[1].Count)
Razem: $($FileList[0].Count+$FileList[1].Count)
"
function Get-FileInfoStr { param( $shellFolder, $shellFile1 )
  "tm.$(($shellFile1.ModifyDate).ToString("yyyy-MM-dd_hh.mm.ss")) s.$($shellFile1.Size);"+
  "$(( (27,28,30,31,32,174,175,176,177,178,259,260,261,262,263,264,270,275,314,316,315,319) | 
       foreach { $($shellFolder.GetDetailsOf($shellFile1,$_)) } ) -join ','))"
}
for ($iv = 0; $iv -lt 2 ; $iv++) { # najpierw _img potem _vid
  $category[$iv]
  ($DestPath = $Shell.NameSpace(@($MyPictures,$MyVideos)[$iv]).Self.Path)
  $Lp = 0
  $FileList[$iv] | 
  foreach { 
    $imgName1 = $_ -replace '^\D*'; <#>$imgName1<##> #- usuń początkowe nie-cyfry
    #                                   yyyy   -    MM   -  dd  _    hh  .   mm . ...   ext
    $imgName2 = $imgName1 -replace '(\d\d\d\d)\D*(\d\d)\D*(\d\d)\D*(\d\d)\D*(\d\d)(.*)\.(.*)', 
                                       ('$1-$2-$3_$4.$5.$6'+'|'+$phonePostfix[$phone.Name]+'.$7')
    if ($imgName2 -eq $imgName1) { # Jeśli nie ma takiego wzorca, to próba pobrania daty modyfikacji
      $date = ($shellFile.ModifyDate).ToString("yyyy-MM-dd_hh.mm.ss") # a gdy brak do data aktualna.
      if ($date -lt '1980-01-01') {$date = (get-date).ToString("yyyy-MM-dd_hh.mm.ss")}
      $imgName2 = $date +
                ("_$imgName1"  -replace '(.*)\.(.*)', ('$1'+'|'+$phonePostfix[$phone.Name]+'.$2'))
    }
    $imgName2, $imgExt2 = $imgName2.split('|')

    $yyyy = $imgName2.Substring(0,4)
    $yyyyMMdd = @(10,7) | foreach {$imgName2.substring(0,$_)} # _img: 10zn., _vid: 7zn. tj. yyyy-MM
    $shellFile = $tmpFolder.ParseName($_)
    $Lp++
    $newDirName = "$yyyy\$($yyyyMMdd[$iv])"
    $newFName = "$imgName2"
    "$($Lp.ToString('000')) ~ $_ -> $newFName$imgExt2"
    #($fInfo = Get-FileInfoStr $tmpFolder $shellFile)
    $x=6; $newFName_x=$newFName
    $doMove = 1
    if (Test-Path "$DestPath\$newDirName\$newFName_x$imgExt2" -PathType leaf) {
      $fInfo1 = Get-FileInfoStr $tmpFolder $shellFile
      $fInfo2 = Get-FileInfoStr ($destShFolder=$Shell.NameSpace("$DestPath\$newDirName\").self.GetFolder()) $destShFolder.ParseName("$newFName_x$imgExt2")
      if ($fInfo1 -eq $fInfo2)  { "
        Zaniechano kopiowania - ten plik docelowy już istnieje. Pierwotny pozostaje w fodlerze .tmp     
        "
        $doMove = 0
        # lista plików, które prawdopodobnie są zdublowane - zalegają w .tmp; klucz:nazwa pliku, wartość: nawzwa docelowa
        $DuplicateList["$tmpPath\$_"] = "$DestPath\$newDirName\$newFName_x$imgExt2"
      } else {     
        while (Test-Path "$DestPath\$newDirName\$newFName_x$imgExt2" -PathType leaf) {
          ++$x; ($newFName_x="${newFName}_$x")
          if ($x -gt 44) {break}
        } # nazwa wynikowa gotowa
      }
    }
    if ($doMove) {
      if (!(Test-Path -path "$DestPath\$newDirName")) {New-Item "$DestPath\$newDirName" -Type Directory}
      Move-Item -path "$($shellFile.Path)" -destination "$DestPath\$newDirName\$newFName_x$imgExt2"
    }
  }
} # for ($iv

# nie skopiowane pliki - po porónaniu binarnym - usuwamy

if ($DuplicateList.Count -gt 0) {
  "Są nieskopiowane pliki - gdy identyczne to usuwamy"
  foreach($file0 in $DuplicateList.keys) {
    & fc.exe /b "$file0" "$($DuplicateList[$file0])" > $null
    if ($LastExitCode -eq 0) { 
      "
      Usuwamy 
$file0 
      bo jest identyczny z już istniejącym
$($DuplicateList[$file0])
"
      Remove-Item -LiteralPath $file0
    } else {
        "
=========== UWAGA! ================
      Plik 
$file0 
      wydawał się identyczny z już istniejącym
$($DuplicateList[$file0])
      ale jednak nie jest - sprawdź osobiście co się dzieje.
"
    } 
  }
}

"
KONIEC.
Zamknij to okno.
"

<# Dane charakterystyczne - gdy identyczne: nazwa i dane, to uważam obraz/film za duplikat
 027:.................................Długość : 00:00:04
 028:...............Szybkość transmisji bitów : ‎229kb/s
 030:...........Model aparatu fotograficznego : SM-A405FN
 031:.................................Wymiary : ‪2592 x 4608‬
 032:.......Producent aparatu fotograficznego : samsung
 174:.........................Głębia w bitach : 24
 175:................Rozdzielczość w poziomie : ‎72 dpi
 176:...............................Szerokość : ‎2592 pikseli
 177:..................Rozdzielczość w pionie : ‎72 dpi
 178:................................Wysokość : ‎4608 pikseli
 259:.........................Czas ekspozycji : ‎17 s
 260:.....................Jednostka przysłony : f/1.7
 261:....................Tryb lampy błyskowej : Lampa błyskowa
 262:......................Długość ogniskowej : ‎4 mm
 263:....Długość ogniskowej dla formatu 35 mm : 26
 264:............................Szybkość ISO : ISO-640
 270:..............................Orientacja : Obróć o 270 stopni
 275:.........................Równowaga bieli : Automatycznie
 314:.........................Wysokość klatki : 1080
 316:........................Szerokość klatki : 1920
 315:................Liczba klatek na sekundę : 30.03 klatek na sekundę
 319:........................Orientacja wideo : 90
#>
