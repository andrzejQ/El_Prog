#!/usr/bin/env python

import xmltodict # python -m pip install xmltodict
# import json
import csv

with open('a.xml') as fd:
  di = xmltodict.parse(fd.read())
# print(f'{di=}'); exit() #py 3.8+
# di={'root': {'p1': {'@a': 'Aa1', '@b': 'Bb1'}, 'p2': {'@a': 'Aa2', '@c': 'Cc2'}, 'p3': {'@a': 'Aa3', '@b': 'Bb3'}}}

d = []
hdr= {} # nagłówek z unikalnymi polami
nElKeys = 2 # liczność początkowych el. listy słowników do wyznaczenia nagł. albo -1

for k,v in di['root'].items():
  d += [{'p':k, **v}]
  if nElKeys != 0:
    hdr = dict.fromkeys(list(hdr.keys()) + list(d[-1].keys())) # py 3.7+ - ordered dict 
  if nElKeys > 0: nElKeys -= 1

# print(json.dumps(d, ensure_ascii=False, indent=2))
print(f'hdr: {hdr.keys()}')

with open('b.csv','w',newline='',encoding='utf-8-sig') as csvF:
  csvDiWr=csv.DictWriter(csvF,fieldnames=hdr.keys(),extrasaction='raise',delimiter=';',quoting=csv.QUOTE_MINIMAL)
  csvDiWr.writeheader() # https://docs.python.org/3/library/csv.html#csv.DictWriter
  csvDiWr.writerows(d)