#!/usr/bin/env python -i
import csv
from collections import namedtuple

def writeCsv(csvName, csvRows, csvHeader=None, encoding='utf-8-sig', delimiter=';'):
  '''writeCsv(csvName: str, csvRows: [[],...], csvHeader: [] optional, 
encoding: 'utf-8-sig'|'utf-8'|'cp1250'|'utf-16'... optional)
'utf-16' -> BOM_UTF16_LE
  '''
  with open(csvName,'w',newline='',encoding=encoding) as csvF:
    csvWr = csv.writer(csvF, delimiter=delimiter,quoting=csv.QUOTE_MINIMAL)
    if csvHeader: # nagłówek można też dać jako wiersz[0] w danych
      csvWr.writerow(csvHeader)
    csvWr.writerows(csvRows)


def readCsv(csvName, encoding='utf-8-sig', delimiter=';'): #csvHeader = result.pop(0)
  '''readCsv(csvName: str, encoding: optional)->[[],...]

  >>> writeCsv('writeCsvTst.csv',[[1,2,3],[4,5,6]],['a_1','c.2ć','e_3ę'])
  >>> data=readCsv('writeCsvTst.csv')
  >>> print(data)
  [['a_1', 'c.2ć', 'e_3ę'], ['1', '2', '3'], ['4', '5', '6']]
  '''
  with open(csvName,'r',newline='',encoding=encoding) as csvF:
    return list(csv.reader(csvF, delimiter=delimiter))

def readCsvH(csvName, encoding='utf-8-sig', delimiter=';'):
  '''readCsvH(csvName: str, encoding: optional)-> csvHeader:[], rows:[[],...]

  >>> hd, data=readCsvH('writeCsvTst.csv')
  >>> print(hd, '->', data)
  ['a_1', 'c.2ć', 'e_3ę'] -> [['1', '2', '3'], ['4', '5', '6']]
  '''
  header, rows = [], []
  with open(csvName,'r',newline='',encoding=encoding) as csvF:
    csvIn=csv.reader(csvF, delimiter=delimiter)
    header=next(csvIn)
    for row in csvIn:
      rows += [row]
  return header, rows


def writeCsvNTuple(csvName, arr, encoding='utf-8-sig', delimiter=';'):
  '''writeCsvNTuple(csvName: str, arr: [namedtuple(), ...], encoding: optional)
  '''
  with open(csvName,'w',newline='',encoding=encoding) as csvF:
    writer = csv.writer(csvF, delimiter=delimiter, quoting=csv.QUOTE_MINIMAL)
    writer.writerow(arr[0]._fields) # write csv header
    for row in arr:
      writer.writerow(row)


def readCsvNTuple(csvName, encoding='utf-8-sig', delimiter=';'):
  '''readCsvNTuple(csvName: str, encoding: optional) -> [namedtuple(), ...]

  >>> arr=readCsvNTuple('writeCsvTst.csv')
  >>> print(arr)
  [nTuple(a_1='1', _1='2', e_3ę='3'), nTuple(a_1='4', _1='5', e_3ę='6')]
  >>> writeCsvNTuple('writeCsvTstTuple.csv', arr)
  >>> print(readCsv('writeCsvTstTuple.csv'))
  [['a_1', '_1', 'e_3ę'], ['1', '2', '3'], ['4', '5', '6']]
  '''
  with open(csvName, newline='', encoding=encoding) as csvF:
    reader = csv.reader(csvF, delimiter=delimiter)
    nTuple = namedtuple('nTuple', next(reader), rename=True)  # get names from csv header
    arr = [ nTuple._make(row) for row in reader ] 
  return arr

def readCsvNTuple2(csvName, encoding='utf-8-sig', replHdr={'.':'_', '-':'__'}, delimiter=';'):
  '''readCsvNTuple2(csvName: str, encoding: optional, replHdr:{}) -> [namedtuple(), ...]
  replHdr: optionally makes some correction in the header names; 
  adds some empty values if row is too short

  >>> writeCsv('writeCsvTst2.csv',[[1,2],[3,4,5,6]],['a_1','c.2ć','e_3ę','ż-ź'])
  >>> arr=readCsvNTuple2('writeCsvTst2.csv')
  >>> print(arr)
  [nTuple(a_1='1', c_2ć='2', e_3ę='', ż__ź=''), nTuple(a_1='3', c_2ć='4', e_3ę='5', ż__ź='6')]
  '''
  with open(csvName, newline='', encoding=encoding) as csvF:
    reader = csv.reader(csvF, delimiter=delimiter)
    hdr = next(reader) # get names from csv header
    hdrLen = len(hdr)
    for k,v in (replHdr or {}).items(): hdr = [s.replace(k,v) for s in hdr]
    nTuple = namedtuple('nTuple', hdr, rename=True)  
    arr = [ nTuple._make(row + ['']*(hdrLen-len(row))) for row in reader ] 
  return arr

#=========================================

if __name__ == '__main__':
  for f in [writeCsv, readCsv, readCsvH, writeCsvNTuple, readCsvNTuple, readCsvNTuple2]: print(f.__doc__)
  import doctest
  doctest.testmod()