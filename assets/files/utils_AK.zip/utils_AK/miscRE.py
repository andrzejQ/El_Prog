#!/usr/bin/python3 -i

import re

def multiREsubDi(t, di = {}):
  """multiREsubDi(t: str, di = {})->str
  >>> multiREsubDi(t=' -“A”‒„b”–‘c’—"d"- ', di = {r'[“”„”‘’‚’‛‟]':r'"', r'[‒–—]':r'-'})
  ' -"A"-"b"-"c"-"d"- '
"""                                       #https://en.wikipedia.org/wiki/Quotation_mark
  for k,v in di.items():
    t = re.sub(k,v, t)
  return t


def delRElist(t, toDelList=[]): 
  """delRElist(t: str, toDelList=[])->str
  >>> delRElist(t=' -“A”‒„b”–‘c’—"d"- ', toDelList = [r'[“”„”‘’‚’‛‟]', r'[‒–—]'])
  ' -Abc"d"- '
  """
  for w in toDelList:
    t = re.sub(w,'', t)
  return t

#=========================================

if __name__ == '__main__':
  for f in [multiREsubDi, delRElist]: print(f.__doc__)
  import doctest
  doctest.testmod()
