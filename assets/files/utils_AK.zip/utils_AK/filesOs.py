#!/usr/bin/python3 -i
import os
from glob import iglob, glob
from datetime import date, datetime, timedelta


def getFirstFile(pathname, sortBy=None, reverse=False):
  """getFirstFile(pathname: str, sortBy: None|'name'|'time'|'size')->path
  ex. getFirstFile('*.py')
  >>> getFirstFile('*.py', sortBy='name')
  '__init__.py'
  >>> getFirstFile('x.y') # 'x.y' doesn't exists
  ''
  """
  p = ''
  if not sortBy:
    for p in iglob(pathname): break # 0 or 1 step
  elif sortBy == 'name':
    for p in sorted(glob(pathname),                       reverse=reverse): break
  elif sortBy == 'time':
    for p in sorted(glob(pathname), key=os.path.getmtime, reverse=reverse): break
  elif sortBy == 'size':
    for p in sorted(glob(pathname), key=os.path.getsize,  reverse=reverse): break
  return p


def cacheIsUpToDate(pathname,timeOut_min=3*60+30):
  """cacheIsUpToDate(pathname: str, timeOut_min=3*60+30)-> 0|1:
  Checks if the cache file exists, is not empty and is fresh
  """
  f = getFirstFile(pathname)                                    ;print(f, end=' ') #$#
  cache01 = 0
  if f:
    f_stat = os.stat(f)
    if (f_stat.st_size > 0):
      f_mod_tm = datetime.fromtimestamp(f_stat.st_mtime) ;print(f_mod_tm, end=' ') #$#
      _now = datetime.now()
      if (timeOut_min == 0) or (_now - timedelta(minutes=timeOut_min) < f_mod_tm):
        print('dt=', _now - f_mod_tm,' - cache file is up to date...')             #$#
        cache01 = 1
      else: print('dt=', _now - f_mod_tm,' - cache file must be refreshed...')     #$#
  return cache01


def testAll():
  """
  >>> getFirstFile('*.py', sortBy='name',reverse=True)
  'miscRE.py'
  >>> getFirstFile('*.*', sortBy='size',reverse=True)
  'files.py'
  >>> getFirstFile('*.*', sortBy='size')
  '__init__.py'
  >>> print( cacheIsUpToDate('filesOs.py') ) # doctest:+ELLIPSIS
  filesOs.py ... - cache file is up to date...
  1
  >>> print( cacheIsUpToDate('mi*.py', timeOut_min=1) ) # doctest:+ELLIPSIS
  misc1.py 20... dt= ... - cache file must be refreshed...
  0
  >>> print( cacheIsUpToDate('x.y', timeOut_min=1) ) #not exists
   0
  >>> print( cacheIsUpToDate('__init__.py', timeOut_min=1) ) #is empty
  __init__.py 0
  """
  pass

#=========================================

if __name__ == '__main__':
  for f in [getFirstFile, cacheIsUpToDate]: print(f.__doc__)

  print("doctest: We assume that 'filesOs.py' has just been saved")
  import doctest
  doctest.testmod()
