#!/usr/bin/python3 -i


def multiReplDi(t, di = {}):
  '''multiReplDi(t: str, di = {})->str
  >>> multiReplDi(t=' mgr inż. płk. ', di = {'ł':'l', 'ó':'o', 'ż':'z'})
  ' mgr inz. plk. '
  '''
  for k,v in di.items():
    t = t.replace(k,v)
  return t


def delByList(t, toDelList=[]): 
  '''delByList(t: str, toDelList=[])->str
  >>> delByList(t='prof. dr hab. mgr inz. arch. lek. lic.', toDelList=['inz','mgr','zw','arch','lek','lic','.',',',' '])
  'profdrhab'
  '''
  for w in toDelList:
    t = t.replace(w,'')
  return t


def dictGetNKeys(dic, default, *keys):
  '''dictGetNKeys(dic: dict, default, *keys)->dic[key1][key2]... or default
  >>> dic={'a':'AA','b':{'i':'II'}}
  >>> dictGetNKeys(dic,'xyz','b','i')
  'II'
  >>> dictGetNKeys(dic,'xyz','b','i2')
  'xyz'
  >>> dictGetNKeys(dic,'xyz','a')
  'AA'
  '''
  v = default
  di = dic
  for key in keys:
    if type(di) is not dict: break
    di = di.get(key) #; print(f'''{key}_:_{di}''') #$#
  else: v = di if di is not None else default
  return v

#=========================================

if __name__ == '__main__':
  for f in [multiReplDi, delByList, dictGetNKeys]: print(f.__doc__)
  import doctest
  doctest.testmod()
