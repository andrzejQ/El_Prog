﻿<# 
  Konwersja do wiersza CSV ciągu łańcuchów.
  W PowerShell 5.1 konwersja do CSV powoduje zawsze otaczanie każdej komórki cudzysłowami. Nie działa -UseQuotes AsNeeded z v.7.
  Przygotowałem sobie własną konwersję z opcjonalnym otaczaniem.
#>
Set-StrictMode -Version 3

function encCsvRow {param( [string[]]$strArr ) #dodaje okalające cudzysłowy, gdy trzeba i łączy wiersz CSV
  ($strArr | foreach {$s = $_ -replace '"','""'; if ($s -match '[;"\r\n]') {$s = "`"$s`""}; $s}) -join ";"
}#encCsvRow @("abc","`"ab`"c;ą`r`nć",'ef"g','h,i','j;k') 
#        ->     abc;"""ab""c;ą`r`nć";"ef""g";h,i;"j;k"  , gdzie `r`n = nowy wiersz
#test, niewidoczne znaki końca wiersza zamieniane na widoczne \r\n:
$x = @(
@("abc", "`"ab`"c;ą`r`nć", 'ef"g', 'h,i', 'j;k'),
"`"ab`"c-ą`r`nć",
$null,
@('m',$null,'n','','o')
''
) | foreach {(encCsvRow $_) -replace '\r','\r' -replace '\n','\n'} 
# $x | foreach { [Regex]::Escape($_) } # - pokazuje niewidoczne znaki
$x #out:
@'
abc;"""ab""c;ą\r\nć";"ef""g";h,i;"j;k"
"""ab""c-ą\r\nć"

m;;n;;o

'@ -eq ($x -join ("`r`n"))

'','------ pojedynczy łańcuch ----------'

function encCsvStr { param( [string]$s_ ) # dodaje okalające cudzysłowy gdy trzeba
  $s = $s_ -replace '"','""'
  if ($s -match '[;"\r\n]') { $s = "`"$s`"" }
  $s
} #
[Regex]::Escape((encCsvStr "`"ab`"c;ą`r`nć")) #-> """ab""c;ą\r\nć"
[Regex]::Escape((encCsvStr "abc"))            #-> abc

'------ gdy chcemuy uniknąc otaczania cudzysłowmi: ----------'
function clrCsv { param( [string[]]$strArr ) # usuwa znaki wymuszające cudzysłowy; gdy '"' nie jest na pocz. to wchodzi dobrze w Excelu
  ($strArr | foreach { $_ -replace ';',',' -replace '[\r\n]','   ' -replace '^"',' "'}) -join ";" 
}#clrCsv @("abc","`"ab`"c;ą`r`nć",'ef"g','h,i','j;k') 
#     ->      abc; "ab"c,ą      ć;ef"g;h,i;j,k
clrCsv @("abc", "`"ab`"c;ą`r`nć", 'ef"g', 'h,i', 'j;k') #-> 'abc; "ab"c,ą      ć;ef"g;h,i;j,k'
""
function clrCsvStr { param( [string]$s ) # usuwa znaki wymuszające cudzysłowy; gdy '"' nie jest na pocz. to wchodzi dobrze w Excelu
  $s -replace ';',',' -replace '[\r\n]','   ' -replace '^"',' "'
} #
clrCsvStr "`"ab`"c;ą`r`nć"  #->  ' "ab"c,ą      ć'



