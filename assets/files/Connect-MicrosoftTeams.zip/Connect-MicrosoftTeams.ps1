﻿# (PSh adm) Set-ExecutionPolicy RemoteSigned
# https://docs.microsoft.com/en-us/microsoftteams/teams-powershell-install
# Install-Module MicrosoftTeams

#przeskocz do foldera skryptu, gdzie zapamiętane będą zaszyfrowane dane logowania:
$Path = $MyInvocation.MyCommand.Path
if ($Path) {
  $Path = Split-Path -Path $Path -Parent; Set-Location $Path
  $CredentialPath = "--$env:COMPUTERNAME!$env:USERNAME!o365.cred" -split '[":/\\]' -join '_'
  if ( Test-Path $CredentialPath ) { 
    $Credential = Import-CliXml -Path $CredentialPath
  } else { # raz pojawi się okno logowania
    $Credential = Get-Credential -Message "....@o365... login:"
    $Credential | Export-CliXml -Path $CredentialPath
  }
  $ConnectTeams = Connect-MicrosoftTeams -Credential $Credential 
}  
else {$ConnectTeams = Connect-MicrosoftTeams}

$ConnectTeams #: Account ... TenantDomain

# Lista zespołów - bez parametrów się zawiesza, więc coś trzeba podać...
$Team = Get-Team -User $ConnectTeams.Account; $Team | Format-Table
$Team[0].DisplayName
# $Team[0] | Get-TeamChannel
$Team[0] | Get-TeamUser
Write-Host 'Wypróbuj: Get-Team -DisplayName "..." | Get-TeamChannel'
