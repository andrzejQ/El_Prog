#!/usr/bin/env python -i

treeStr = f'''\
1
  11
  12
    121
    122
2
3
  31
  32
    321
  33
'''
#https://gist.github.com/hrldcpr/2012250  (autovivification)
from collections import defaultdict
import json
import re

def tree(): return defaultdict(tree)
def add(t, path):
  for node in path: t = t[node]
    
indent='  '; indentLen=len(indent)
dirsIn = treeStr.splitlines()

tree0 = tree(); path = []
for d in dirsIn:
  level=len(re.match(r'\s+',indent+d)[0]) // indentLen #; print(level) #-> 1, ...
  if level > len(path):
    path.append(d.strip())
  else:
    path = path[:level-1]  + [d.strip()]
  add(tree0, path)
  
print(json.dumps(tree0, ensure_ascii=False,indent=2,sort_keys=True))

def prnTree(t, depth = 0):
  for k in t.keys():
    print(f'''{depth}: {"".join(depth * ["+ "])}{k}''')
    depth += 1
    prnTree(t[k], depth)
    depth -= 1
prnTree(tree0)
  
tree1 = tree() #kopia do tree1 i wydruk pełnych ścieżek
def cpTree(t, depth = 1, path = []):
  """ kopiuj drzewo do `tree1` i rozwiń (1:6:1) """
  for k in t.keys():
    #print(f'''{depth}: {"".join(depth * ["  "])}{k}''')
    path = path + [k]
    print(f'''{depth}: {path}''')
    add(tree1,path)
    depth += 1
    cpTree(t[k], depth, path)
    depth -= 1
    path = path[:-1]

cpTree(tree0)
