import os
import shutil
import argparse
import mammoth # pip install mammoth

def cli_args():
  parser = argparse.ArgumentParser(
    usage='python mammothH.py FILE.DOCX',
    description=f'''DOCX -> HTML (mammoth + HTML head)''',)
  parser.add_argument('input_file')
  parser.add_argument('-o', '--output',
                 help='or default FILE.docx_.HTML')
  parser.add_argument('-i', '--img-dir', default='',
                 help='directory for image files or (default) images are included inline in HTML')
  parser.add_argument('-l', '--lang', default='pl-PL', help='e.g.: "pl-PL" (default)')
  parser.add_argument('-s', '--td_style', nargs='+',  default=(':nth-child(1)','color: DarkMagenta;', ':nth-child(3n+4)','color: Blue;'),
                 help='td_sel1, style1, ... e.g.: --td_style ":nth-child(1)" "color: DarkMagenta;" ":nth-child(3n+4)" "color: Blue;"' )
  return parser.parse_args()

def main ():
  args=cli_args() ; print(f'{args=}') #$# py 3.8+
  out_suffix='._.html' #to add if not --output
  output_file = args.output or f'{args.input_file}{out_suffix}' ; print(f'{output_file=}') #$#
  if not args.img_dir:
    convert_image = None
  else:
    if not os.path.exists(args.img_dir):
      os.makedirs(args.img_dir) ; print(f'os.makedirs {args.img_dir}') #$#
    convert_image = mammoth.images.img_element(ImageWriter(args.img_dir))
  tdSel_style = list(zip(args.td_style[::2], args.td_style[1::2])) if args.td_style else [] \
    ; print(f'{tdSel_style=}') #$#
  
  messages = docx_to_html(args.input_file, output_file, args.lang, convert_image, tdSel_style)
  print(f'{messages=}\n.')

def docx_to_html(input_file, output_file, lang='', convert_image=None, tdSel_style=[]):
  with open(input_file, "rb") as docx_file:
    
    result = mammoth.convert_to_html(docx_file, convert_image=convert_image)
    
    html = (f'''<!DOCTYPE html><html><head><meta charset="utf-8"/>
<style>
 body {{ font-family: "Segoe UI","Noto Sans",Helvetica,Arial,sans-serif; }}
 {' '.join([f'td{selector}, th{selector} {{{style}}}' for (selector,style) in tdSel_style])}
 table {{border-collapse: collapse; }}
 th, td {{border: 1px solid grey; font-size: 0.85em; padding:2px;}}
 td p {{margin: 0px;}}
</style>
<title>{output_file}</title>
</head><body{f' lang="{lang}"' if lang else ''}> 
{result.value}
</body></html>
''') 

    with open(output_file, "w", encoding="utf-8") as f: 
      f.write(html)
  return result.messages

class ImageWriter(object):
# Python___\Lib\site-packages\mammoth\cli.py
  def __init__(self, output_dir):
    self._output_dir = output_dir
    self._image_number = 1
  def __call__(self, element):
    extension = element.content_type.partition("/")[2]
    image_filename = f"{self._image_number}.{extension}"
    img_path = os.path.join(self._output_dir, image_filename)
    with open(img_path, "wb") as image_dest:
      with element.open() as image_source:
        shutil.copyfileobj(image_source, image_dest)
    self._image_number += 1
    return {"src": img_path}

if __name__ == "__main__":
  main ()