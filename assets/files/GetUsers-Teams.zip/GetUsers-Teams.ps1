﻿<#
  Dla zalogowanego użytkownika pobiera wszystkie jego zespoły i kanały 
  i zapisuje kolejno listę członków zespołów do CSV.
  Wersja General Availability (GA). Zarządzanie członkami kanałów jest obecnie 
  (2020) możliwe tylko w wersji MicrosoftTeams Public Preview, która wymaga osobnej instalacji.
  https://docs.microsoft.com/en-us/microsoftteams/teams-powershell-install
#>
# Install-Module MicrosoftTeams
Set-StrictMode -Version 3

#przeskocz do foldera skryptu, gdzie zapamiętane będą zaszyfrowane dane logowania:
$Path = $MyInvocation.MyCommand.Path
if ($Path) {
  $Path = Split-Path -Path $Path -Parent; Set-Location $Path
  $CredentialPath = "--$env:COMPUTERNAME!$env:USERNAME!o365.cred" -split '[":/\\]' -join '_'
  if ( Test-Path $CredentialPath ) { 
    $Credential = Import-CliXml -Path $CredentialPath
  } else { # raz pojawi się okno logowania
    $Credential = Get-Credential -Message "....@o365... login:"
    $Credential | Export-CliXml -Path $CredentialPath
  }
  $ConnectTeams = Connect-MicrosoftTeams -Credential $Credential 
} else {$ConnectTeams = Connect-MicrosoftTeams}
$ConnectTeams | select Account, TenantDomain

# Lista zespołów - Get-Team bez parametrów się zawiesza, więc coś trzeba podać...
$Teams_ = Get-Team -User $ConnectTeams.Account; $Teams_ | select DisplayName, Description, Visibility | Format-List

# Zapis kolejnych list do pliku
$outPath="$((Get-Date).ToString('yyyy-MM-dd_HH.mm'))-TeamsUsers.csv"
"User;Name;Role" | Out-File $outPath -Encoding utf8 
# Na początku każdej grupy będzie "..;<nazwa zespołu>" i ".;<nazwa zespołu>;<nazwa kanału>" 
foreach ($te in $Teams_) {
  Write-Host $te.DisplayName
  "..;$($te.DisplayName);" | Out-File $outPath -Encoding utf8 -Append
  $Channels_ = $te | Get-TeamChannel
  foreach ($ch in $Channels_) {
    ".;$($te.DisplayName);$($ch.DisplayName)" | Out-File $outPath -Encoding utf8 -Append
  }
  $Users_ = $te | Get-TeamUser | select User,Name,Role
  $i_ = 0; foreach ($us in $Users_) { $i_++
    "$($us.User);$($us.Name);$($us.Role)"| Out-File $outPath -Encoding utf8 -Append
  }
  Write-Host "`tu:`t$i_"
}
Write-Host "Dane zapisano do pliku: $outPath"
Invoke-Item ".\$outPath" # otwiera plik CSV w domyślnej aplikacji