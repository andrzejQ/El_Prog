﻿<# === GetUsers-Teams.ps1 ===
  Skrypt pobiera listę zespołów użytkownika Office365 i dla każdego z zespołów pobiera kanały 
  i listę członków zespołu. Wynik zapisuje do pliku CSV (który jest automatycznie otwierany):  
User;Name;Role
..;Mój zespół1;
.;;Kanał 1
.;;Kanał 2
uż.1@o365;Imię Nazw.1;owner
uż.2@o365;Imię Nazw.1;member

  Po jednorazowym zapytaniu o login i hasło zapamiętuje je zaszyfrowane w pliku "...!o365.cred" 

  Jest to wersja dla modułu MicrosoftTeams - General Availability (GA) v.1.1.6, która pozawala zarządzać 
  członkami zespołów. Zarządzanie członkami kanałów jest obecnie (2020r) możliwe tylko w wersji 
  MicrosoftTeams Public Preview (np. v.1.1.7), która wymaga osobnej instalacji. 
  https://docs.microsoft.com/en-us/microsoftteams/teams-powershell-install
#>
# Install-Module MicrosoftTeams
Set-StrictMode -Version 3
Write-Host -ForegroundColor DarkYellow "Czasem trzeba trochę poczekać..."
#przeskocz do foldera skryptu, gdzie zapamiętane będą zaszyfrowane dane logowania:
$Path = $MyInvocation.MyCommand.Path
if ($Path) {
  $Path = Split-Path -Path $Path -Parent; Set-Location $Path
  $CredentialPath = "--$env:COMPUTERNAME!$env:USERNAME!o365.cred" -split '[":/\\]' -join '_'
  if ( Test-Path $CredentialPath ) { 
    $Credential = Import-CliXml -Path $CredentialPath
  } else { # raz pojawi się okno logowania
    $Credential = Get-Credential -Message "....@o365... login:"
    $Credential | Export-CliXml -Path $CredentialPath
  }
  $ConnectTeams = Connect-MicrosoftTeams -Credential $Credential 
} else {$ConnectTeams = Connect-MicrosoftTeams}
$ConnectTeams | select Account, TenantDomain

# Lista zespołów - Get-Team bez parametrów się zawiesza, więc coś trzeba podać...
$Teams_ = Get-Team -User $ConnectTeams.Account; $Teams_ | select DisplayName, Description, Visibility | Format-List

function encCsv { param( [string]$s ) # dodaje okalające cudzysłowy, gdy trzeba
  $s = $s -replace '"','""'
  if ($s -match '[;"\r\n]') { $s = "`"$s`"" }
  $s
}#[System.Text.RegularExpressions.Regex]::Escape((encCsv "`"ab`"c;ą`r`nć")) #-> """ab""c;ą\r\nć"

# Zapis kolejnych list do pliku
$outPath="$((Get-Date).ToString('yyyy-MM-dd_HH.mm'))-TeamsUsers.csv"
"User;Name;Role" | Out-File $outPath -Encoding utf8 
# Na początku każdej grupy będzie "..;<nazwa zespołu>" i ".;<nazwa zespołu>;<nazwa kanału>" 
foreach ($te in $Teams_) {
  Write-Host $te.DisplayName
  "..;$(encCsv $te.DisplayName);" | Out-File $outPath -Encoding utf8 -Append
  $Channels_ = $te | Get-TeamChannel
  foreach ($ch in $Channels_) {
    ".;;$(encCsv $ch.DisplayName)" | Out-File $outPath -Encoding utf8 -Append
  }
  $Users_ = $te | Get-TeamUser | select User,Name,Role
  $i_ = 0; foreach ($us in $Users_) { $i_++
    "$(encCsv $us.User);$(encCsv $us.Name);$(encCsv $us.Role)"| Out-File $outPath -Encoding utf8 -Append
  }
  Write-Host "`tu:`t$i_"
}
Write-Host "Dane zapisano do pliku: $outPath"
Invoke-Item ".\$outPath" # otwiera plik CSV w domyślnej aplikacji