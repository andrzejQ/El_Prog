﻿<# === AddUsers-Teams.ps1 ===
  Automatyczne uaktualnianie człnków zespołów.
  Skrypt Odczytuje plik CSV o formacie jak w skrypcie GetUsers-Teams.ps1
User;Name;Role
..;Mój zespół1;
.;;Kanał 1
.;;Kanał 2
uż.1@o365;Imię Nazw.1;owner
uż.2@o365;Imię Nazw.1;member

  Gdy napotka wiersz "..;<nazwa zespołu>;" uaktualnia istniejący zespół zalogowanego użytkownika 
  (albo tworzy nowy, gdy potrzeba - ale raczej powinno się tworzyć zespoły ręcznie korzystając z szablonów).
  Dodaje kanały jeśli są nowe, wg. wierszy w CSV ".;;<nazwa kanału>".
  Dodaje członków wg. odczytywanej listy członków zespołu w CSV, ale tylko jeśli są nowi. 
  2-ga kolumna ("Name") jest pomijana podczas operacji dodawania (nie da się w ten sposób zmodyfikować 
  imienia i nazwiska użytkownika).
  W 3-ciej kolumnie ("Role") w przypadku dodawania użytkownika ważny jest wpis "owner", a każdy inny 
  jest zamieniany na "member".
  Może być wiele sekcji zespół-kanały-użytkownicy.
  
  Nie usuwa członków, których brak na liście CSV.
  
  Po jednorazowym zapytaniu o login i hasło zapamiętuje je zaszyfrowane w pliku "...!o365.cred" 
  - wspólnym dla tej rodziny skryptów.

  Jest to wersja dla modułu MicrosoftTeams - General Availability (GA) v.1.1.6, która pozawala zarządzać 
  członkami zespołów. Zarządzanie członkami kanałów jest obecnie (2020r) możliwe tylko w wersji 
  MicrosoftTeams Public Preview (np. v.1.1.7), która wymaga osobnej instalacji. 
  https://docs.microsoft.com/en-us/microsoftteams/teams-powershell-install
#>
# Install-Module MicrosoftTeams
Set-StrictMode -Version 3

$inCsvFile = "_TeamsUsers_.csv" # domyślna nazwa, ale będzie pytanie o wybór pliku...

Write-Host -ForegroundColor DarkYellow "Czasem trzeba trochę poczekać..."
#przeskocz do foldera skryptu, gdzie zapamiętane będą zaszyfrowane dane logowania:
$Path = $MyInvocation.MyCommand.Path
if ($Path) { $Path = Split-Path -Path $Path -Parent; Set-Location $Path }

$FileDialog = New-Object Windows.Forms.OpenFileDialog   
  $FileDialog.Title = "Listy członków TEAMS do dopisania w moich zespołach (!)"
  $FileDialog.initialDirectory = $Path; $FileDialog.filter = "CSV (*.csv)|*.csv"; 
  $FileDialog.FileName = $inCsvFile
$FileDialog.ShowDialog();$inCsvFile = $FileDialog.FileName; 
"Listy zespołów wczytane z: $inCsvFile"

if ($Path) {
  $CredentialPath = "--$env:COMPUTERNAME!$env:USERNAME!o365.cred" -split '[":/\\]' -join '_'
  if ( Test-Path $CredentialPath ) { 
    $Credential = Import-CliXml -Path $CredentialPath
  } else { # raz pojawi się okno logowania
    $Credential = Get-Credential -Message "....@o365... login:"
    $Credential | Export-CliXml -Path $CredentialPath
  }
  $ConnectTeams = Connect-MicrosoftTeams -Credential $Credential 
} else {$ConnectTeams = Connect-MicrosoftTeams}
$ConnectTeams | select Account, TenantDomain

# Lista zespołów - Get-Team bez parametrów się zawiesza, więc coś trzeba podać...
$Teams_ = Get-Team -User $ConnectTeams.Account; $Teams_ | select DisplayName, Description, Visibility | Format-List

function clearTxt { # dla dopasowania nazwy zespołu
  param( [string]$s ) # usuwa niepotrzebne spacje, zostawia tylko znaki tekstu, bez różnych '"' czy '-'
  $s.Trim() -replace '\s+',' ' -replace '\W','_'
} #clearTxt '    alc-"x   ąłć    ĄŁĆ   '  ->  'alc__x_ąłć_ĄŁĆ'

$orgTeams = @{} #oryginalna lista zespołów - do aktualizacji
foreach ($te in $Teams_) { $orgTeams[(clearTxt $te.DisplayName)] = $te }; #$orgTeams

$inCsv = Import-Csv -delimiter ";" -encoding utf8 $inCsvFile
$team_ = $channels_ = $users_ = $null; 
foreach ($r in $inCsv) {
  if (".." -eq $r.User) {
    Write-Host "$($r.User) Zespół: $($r.Name)"
    $teKey = clearTxt $r.Name
    if ($orgTeams.Keys -contains $teKey) {
      Write-Host "...uaktualnienie."
      $team_ = $orgTeams[$teKey]
      # odczytaj kanały i użytkowników
      $channels_ = $team_ | Get-TeamChannel | select DisplayName
      $users_    = $team_ | Get-TeamUser | select User
    }
    else {
      Write-Host "...NOWY ZESPÓŁ ! (nie zalecane)"
      $team_ = $channels_ = $users_ = $null; 
      #break # na razie - ogólnie to działa
      $team_ = New-Team -displayname ($r.Name) -Visibility "private"
      $channels_ = $team_ | Get-TeamChannel | select DisplayName
    }
  }
  elseif ($team_ -and ("." -eq $r.User)) {
    $chName = $r.Role
    Write-Host "`t Kanał: $chName"
    if (-not $Channels_ -or ($Channels_.DisplayName -notcontains $chName)) {
      Write-Host -ForegroundColor Yellow "`t ...DODANO NOWY KANAŁ."
      New-TeamChannel -GroupId ($team_.GroupId) -DisplayName $chName      
    }
  }                                                                         
  elseif ($team_ -and (($r.User).Length -gt 3)) {
    $role_ = $r.Role; if ($role_ -ne "owner") {$role_ = "member"}
    Write-Host "`t`t $($r.Name): $($r.User) ~ $($role_)"
    if (-not $Users_ -or ($Users_.User -notcontains $r.User)) {
      Write-Host -ForegroundColor Yellow "`t`t ...NOWY UŻYTKOWNIK."
      Add-TeamUser -GroupId ($team_.GroupId) -User ($r.User) -Role ($role_)
    }
  }
}

Write-Host "KONIEC."
