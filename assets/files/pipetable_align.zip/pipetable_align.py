#!/usr/bin/env python
import sys
import re
'''
Aligns vertical `|` in the pipetable with spaces.
Skips alignment when texts are too long.
'''
permWidth = [100, 80] # Longer texts in these columns will not be aligned
_new = "-MDpt"

def main ():
  md_file_name = sys.argv[1] if len(sys.argv) > 1 else "x.md"
  print(f' {md_file_name=}')
  with open(md_file_name, encoding='utf-8-sig') as txt:
    text_md = txt.read().splitlines()

  out_md = format_table(text_md)

  out_file_name = re.sub(r'(.*)\.', fr'\1{_new}.', md_file_name, 1)
  print(f'{out_file_name=}')
  with open(out_file_name,'w',newline='\r\n',encoding='utf-8-sig') as txt:
    txt.write('\n'.join(out_md))


def format_table(text_md):
  '''
  >>> format_table(
  ... ['aaa',
  ... '| z | y |',
  ... '|--------|---|',
  ... '| zz | yy4yy |'])
  ['aaa', \
'| z  | y     |', \
'|----|-------|', \
'| zz | yy4yy |', \
'']'''
  out_md = []
  table = []
  if text_md[-1].startswith('|'):
    text_md += [''] # An empty row below the table to end it
  for row in text_md:
    if not row.startswith('|'):
      if table: # This means the end of the table
        out_md += add_spaces_in(table)
        table = []
      out_md += [row]
    else: # row.startswith('|')
      table += [row]
  return out_md


def add_spaces_in(table):
  outTabl = []
  # determination of the common width of columns
  CNT = len(permWidth)
  maxWidth = [3] * CNT          # 1        2     3
  tableRow    = re.compile(r'^'+r'(\|.*?)'*CNT+r'(\|.*)$')
  tableLineHd = re.compile(r'^'+r'(\|.*?(\-{3,}).*?)'*CNT+r'\|')
  for row in table:             # 1     2             3 4
    m = re.search(tableRow, row)
    if (m):
      column = m.groups() # ( m[1],m[2],... m[CNT+1] )
      column = [ col.rstrip() for col in column[:CNT] ] + list(column[CNT:])
      m_ = re.search(tableLineHd, row)
      if (m_): # case | :--- and shorter texts column
        maxWidth = [max(maxW, 3+col.count(':')+col.count(' '))  for maxW, col in zip(maxWidth, column)] 
      else:    # table rows except '-----'
        maxWidth = [max(maxW, len(col)) for maxW, col in zip(maxWidth, column)]
    #$# print(maxWidth, row) #$#
  maxWidth = [min(w, p)+1 for w, p in zip(maxWidth, permWidth)] # +1 because then I'll add a space at the end
  
  for row in table:
    m = re.search(tableRow, row)
    if not m:
      outTabl += [row]
    else:
      column = m.groups()
      column = [ col.rstrip() for col in column[:CNT] ] + list(column[CNT:])
      m_ = re.search(tableLineHd, row)
      if (m_): # lengthening / shortening |-----
        minuses = [ m_[i*2 + 2] for i in range(CNT)]
        #$# print(''.join([f'({len(col)}):{col!r}' for col in column[:CNT]]),' '.join([f'--- ({len(mi)})' for mi in minuses])) #$#
        for i, (mins, col, maxW) in enumerate( zip(minuses, column, maxWidth) ):
          if   (len(col) < maxW): # i.e. column |----- too short
            column[i] = col.replace('-', '-'*(maxW - len(col) + 1), 1)  #$#;print(f'###{column=}') #$#
          elif (len(col) > maxW): # i.e. column |----- to long
            column[i] = re.sub(fr'\-{{3,{len(col) - maxW + 3}}}', '---', col, 1)
      else: # not |-----
        column = [ col+' ' for col in column[:CNT] ] + column[CNT:] # .rstrip() eats up the right spaces, and one is worth giving
        idxOverWdth = ([len(col) > mW  for col, mW in zip(column, maxWidth)]+[True]).index(True) +1 # 1 + index of long text column
        tmpColWidth = maxWidth[:idxOverWdth] + [0] * CNT # without additional spaces in next columns if the text is too long
      outTabl += [''.join( [f'{col:{wdth}}' for col,wdth in zip(column, tmpColWidth)] )]
  return outTabl


if __name__ == "__main__":
  #import doctest; doctest.testmod() or \
  main ()
  
