import re
'''
Aligns vertical `|` in the pipetable with spaces.
Skips alignment when texts are too long.
'''
permWidth = [100, 80] # Longer texts in these columns will not be aligned
md_file_name =  "x.md"
new_ = "NEW-"

def main ():
  with open(md_file_name, encoding='utf-8-sig') as txt:
    text_md = txt.read().splitlines()

  out_md = format_table(text_md)

  with open(new_+md_file_name,'w',newline='\r\n',encoding='utf-8-sig') as txt:
    txt.write('\n'.join(out_md))


def format_table(text_md):
  '''
  >>> format_table(
  ... ['aaa',
  ... '| z | y |',
  ... '|--------|---|',
  ... '| zz | yy4yy |'])
  ['aaa', \
'| z  | y     |', \
'|----|-------|', \
'| zz | yy4yy |', \
'']'''
  out_md = []
  table = []
  if text_md[-1].startswith('|'):
    text_md += [''] # An empty row below the table to end it
  for row in text_md:
    if not row.startswith('|'):
      if table: # This means the end of the table
        out_md += add_spaces_in(table)
        table = []
      out_md += [row]
    else: # row.startswith('|')
      table += [row]
  return out_md

def add_spaces_in(table):
  outTabl = []
  # determination of the common width of columns
  CNT = len(permWidth)
  maxWidth = [0] * CNT          # 1        2     3
  tableRow    = re.compile(r'^'+r'(\|.*?)'*CNT+r'(\|.*)$')
  tableLineHd = re.compile(r'^'+r'(\|.*?(\-{3,}).*?)'*CNT+r'\|')
  for row in table:             # 1     2             3 4
    m = re.search(tableRow, row)
    if (m): 
      m_ = re.search(tableLineHd, row)
      if (not (m_)): # table rows except '-----'
        maxWidth = [max(w, len(g.rstrip())) for w, g in zip(maxWidth, m.groups())]
  #$# print(maxWidth, row) #$#
  maxWidth = [min(w, p)+1 for w, p in zip(maxWidth, permWidth)] # +1 because then I'll add a space at the end
  
  for row in table:
    m = re.search(tableRow, row)
    if not m:
      outTabl += [row]
    else:
      tmpColWidth=maxWidth[:] + [0] # the last part of the columns without changing the width
      column = m.groups() #[ m[1],m[2],... m[CNT+1] ]
      column = [ col.rstrip() for col in column[:-1] ] + [ column[-1] ]
      minuses = [''] * CNT
      m_ = re.search(tableLineHd, row)
      if (m_): # lengthening / shortening |-----
        for i in range(CNT):
          minuses[i] = m_[i*2 + 2]
          #$# print(''.join([f'({len(col)}):{col!r}' for col in column[:CNT]]),' '.join([f'--- ({len(mi)})' for mi in minuses])) #$#
          if (len(column[i]) < maxWidth[i]): # tj. column |----- too short
            column[i] = column[i].replace('-', '-'*(maxWidth[i] - len(column[i]) + 1), 1)  #$#;print(f'###{column[i]!r}{column[1]!r}') #$#
          elif ((len(column[i]) > maxWidth[i]) and (len(minuses[i]) > 3)): # i.e. column |----- to long
            n = len(column[i]) - maxWidth[i] + 3
            if (n > 0):
              column[i] = re.sub(fr'\-{{3,{n}}}', '---', column[i], 1)
      else: # not |-----
        column = [col + ' ' for col in column[:-1]] + [column[-1]] # .rstrip() eats up the right spaces, and one is worth giving
        for i in range(1, len(tmpColWidth)):
          if ((tmpColWidth[i-1] == 0) or (len(column[i-1]) > maxWidth[i-1])):
            tmpColWidth[i] = 0 # without additional spaces in the next column and further if the text is too long in the column
      outTabl += [''.join( [f'{col:{wdth}}' for col,wdth in zip(column, tmpColWidth)] )]
  return outTabl

if __name__ == "__main__":
  #import doctest; doctest.testmod() or \
  main ()
  print('.')
