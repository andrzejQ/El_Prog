﻿using System;
using System.Globalization;

namespace DateTime1
{
    public class Example
    {
        public static void Main()
        {
            string[] dateTimeTestStrings = {
                "05/01/2009 14:57:32.8"
                , "2009-05-01 14:57:32.8"
                , "2009-05-16 14:57:32.8"
                ,"2009-05-01T14:57:32.8375298-04:00"
                , "5/20/2008"
                , "20/05/2008"
                , "6/21/2008 14:57:32.80 -07:00"
                , "15 May 2008 2:57:32.8 PM"
                , "Fri, 15 May 2009 20:10:57 GMT"
                , "2009.05.01 01:00:32"
                , "2009-05-01"
                , "17-05-2009 01:00:32"
                , "18.05.2009 01:00:32"
                , "19.05.2009"
            };
            DateTime dateValue;

            Console.WriteLine("Attempting to parse strings using {0} culture.", CultureInfo.CurrentCulture.Name);
            foreach (string dateString in dateTimeTestStrings)
            {
                CultureInfo ddMMyyyCI = new CultureInfo("pl-PL", false); 
                    // "pl-PL" or any other culture with dd at the beginning (PL: dd.MM.yyyy)
                    // without the user-selected culture settings. 
                if (DateTime.TryParse(dateString, out dateValue)) 
                    // local culture with user-selected culture settings in the system
                    // yyyy MM dd are also parsed
                    Console.WriteLine("  Converted -> '{0}' to {1} ({2}).", dateString, dateValue, dateValue.Kind);
                else if (DateTime.TryParse(dateString, ddMMyyyCI // dd at the beginning case
                    , DateTimeStyles.AssumeLocal | DateTimeStyles.AllowWhiteSpaces, out dateValue))
                    Console.WriteLine("  Converted dd.MM.yyyy '{0}' to {1} ({2}).", dateString, dateValue, dateValue.Kind);
                else
                    Console.WriteLine("  Unable to parse '{0}'.", dateString);
            }
            DateTime now = DateTime.Now;
            Console.WriteLine("local   : " + now.ToString());
            Console.WriteLine("sortable: " + now.ToString("u"));
        }
    }

}

/* Gdy format lokalny dd.MM.yyy
Attempting to parse strings using pl-PL culture.
  Converted -> '05/01/2009 14:57:32.8' to 05.01.2009 14:57:32 (Unspecified).
  Converted -> '2009-05-01 14:57:32.8' to 01.05.2009 14:57:32 (Unspecified).
  Converted -> '2009-05-16 14:57:32.8' to 16.05.2009 14:57:32 (Unspecified).
  Converted -> '2009-05-01T14:57:32.8375298-04:00' to 01.05.2009 20:57:32 (Local).
  Unable to parse '5/20/2008'.
  Converted -> '20/05/2008' to 20.05.2008 00:00:00 (Unspecified).
  Unable to parse '6/21/2008 14:57:32.80 -07:00'.
  Converted -> '15 May 2008 2:57:32.8 PM' to 15.05.2008 14:57:32 (Unspecified).
  Converted -> 'Fri, 15 May 2009 20:10:57 GMT' to 15.05.2009 22:10:57 (Local).
  Converted -> '2009.05.01 01:00:32' to 01.05.2009 01:00:32 (Unspecified).
  Converted -> '2009-05-01' to 01.05.2009 00:00:00 (Unspecified).
  Converted -> '17-05-2009 01:00:32' to 17.05.2009 01:00:32 (Unspecified).
  Converted -> '18.05.2009 01:00:32' to 18.05.2009 01:00:32 (Unspecified).
  Converted -> '19.05.2009' to 19.05.2009 00:00:00 (Unspecified).
local   : 15.02.2023 08:48:18
sortable: 2023-02-15 08:48:18Z
*/

/* Gdy format lokalny yyyy-MM-dd 
Attempting to parse strings using pl-PL culture.
  Converted -> '05/01/2009 14:57:32.8' to 2009-05-01 14:57:32 (Unspecified).
  Converted -> '2009-05-01 14:57:32.8' to 2009-05-01 14:57:32 (Unspecified).
  Converted -> '2009-05-16 14:57:32.8' to 2009-05-16 14:57:32 (Unspecified).
  Converted -> '2009-05-01T14:57:32.8375298-04:00' to 2009-05-01 20:57:32 (Local).
  Converted -> '5/20/2008' to 2008-05-20 00:00:00 (Unspecified).
  Converted dd.MM.yyyy '20/05/2008' to 2008-05-20 00:00:00 (Local).
  Converted -> '6/21/2008 14:57:32.80 -07:00' to 2008-06-21 23:57:32 (Local).
  Converted -> '15 May 2008 2:57:32.8 PM' to 2008-05-15 14:57:32 (Unspecified).
  Converted -> 'Fri, 15 May 2009 20:10:57 GMT' to 2009-05-15 22:10:57 (Local).
  Converted -> '2009.05.01 01:00:32' to 2009-05-01 01:00:32 (Unspecified).
  Converted -> '2009-05-01' to 2009-05-01 00:00:00 (Unspecified).
  Converted dd.MM.yyyy '17-05-2009 01:00:32' to 2009-05-17 01:00:32 (Local).
  Converted dd.MM.yyyy '18.05.2009 01:00:32' to 2009-05-18 01:00:32 (Local).
  Converted dd.MM.yyyy '19.05.2009' to 2009-05-19 00:00:00 (Local).
local   : 2023-02-15 08:46:37
sortable: 2023-02-15 08:46:37Z
*/