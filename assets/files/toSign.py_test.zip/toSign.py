import pdfplumber # pip install pdfplumber
import pyhanko    # pip install pyHanko
from pyhanko.sign.fields import SigFieldSpec, append_signature_field
from pyhanko.pdf_utils.incremental_writer import IncrementalPdfFileWriter
from pyhanko.sign import fields
import shutil
import argparse

def cli_args():
  parser = argparse.ArgumentParser(
    prog='toSign',
    description=f'''Replace specific graphical objects with an empty signature fields.
  Objects like rectangles or table cell containig text starting with pattern.
  Loop on pages from list like [0, 1, -1] i.e. first, second and last page.''',)
  parser.add_argument('input_file')
  parser.add_argument('-o', '--output')
  parser.add_argument('-t', '--txt_pattern', default='signature field')
  parser.add_argument('-p', '--pages', default=[0, 1, -1]) #Pages to analyse
  return parser.parse_args()

def main ():
  args=cli_args() ;print(f'{args=}') #$# py 3.8+
  out_suffix='_toSign' #to insert before last '.pdf' in output file of not --output
  output_file = args.output or f'{args.input_file[:-4]}{out_suffix}{args.input_file[-4:]}'
  print(f'{output_file=}') #$#
  shutil.copy(args.input_file, output_file)
  # # #
  addSignatureFields(output_file, args.txt_pattern, args.pages)

def addSignatureFields(path, pattern, pages):
#  https://github.com/MatthiasValvekens/pyHanko/issues/8#issuecomment-803586088
#
#  Objects to place empty signature field on it are:
#  - Rectangles containing a string that starts with the string specificed in pattern
#  The rectangles may have any linecolor, linewidth (including 0 pts) and filling color
#  The string may have any color, font and font size. Even a white box with white text 
#  on white background should be sufficient. Cannot be used inside a table cell. 
#  - Table cells containing a string that starts with the string specificed in pattern
#  All four cell borders must be visible in the PDF file
#
# INPUT:
#   path: Path to PDF file to be processed. The file will be replaced with the resulting file
#   pattern: String to match (startwith, case insensitive) against cell/rect content
#   pages: Pages to analyse, e.g. [0, 1, -1] will analyze the first two and the last page if they exist. Use None for all pages.
#
# RETURN: 
#   Number of signature fields added to the PDF
#
  def intersects(box1, box2):
    return not (box1[2] <= box2[0] or box1[0] >= box2[2] or box1[3] <= box2[1] or box1[1] >= box2[3])

  pattern = pattern.lower()

  with pdfplumber.open(path) as inpdf:
    with open(path, 'rb+') as outpdf:
      iFieldCounter = 1
      w = IncrementalPdfFileWriter(outpdf)
      
      if not pages:
        page_selection = range(len(inpdf.pages))
      else:
        _max_page = len(inpdf.pages)
        page_selection = set([(p % _max_page) for p in pages if (p >=-_max_page and p < _max_page)])
      print(f'{page_selection=}') #$#
      for p in page_selection:
        page =inpdf.pages[p]
        # occupied_boxes contains a list of areas where no further field can be placed. These areas 
        # include bounding boxes of fully analyzed tables and already placed signature fields
        occupied_boxes = []

        for table in page.find_tables():
          for c, cell in enumerate(table.cells):
            cell_bbox = [cell[0], cell[1], cell[2], cell[3]]
            cell_text = page.crop(cell_bbox).extract_text()
            if cell_text and cell_text.strip().lower().startswith(pattern):
              intersect = False
              for t in occupied_boxes:
                if intersect := intersects(t, cell_bbox): break
              if not intersect:
                print(f"Placing signature field {iFieldCounter} in table cell {c} on page {p}")
                occupied_boxes.append(cell_bbox)
                append_signature_field(w, SigFieldSpec(sig_field_name=f"Signature {iFieldCounter}", on_page=p,
                  box=[1.01 * cell[0], page.height - 1.01 * cell[1], 0.99 * cell[2], page.height - 0.99 * cell[3]]))
                iFieldCounter += 1
          occupied_boxes.append(table.bbox)
        
        for rect in page.rects:
          try:
            rect_bbox = [rect['x0'],rect['top'],rect['x1'],rect['bottom']]
            rect_text = page.crop(rect_bbox).extract_text() 
          except ValueError:
            print("Error. Perhaps a rect reaches outside of the page")
          if rect_text and rect_text.strip().lower().startswith(pattern):
            intersect = False                #;print(f'{rect_bbox=}') #$#
            for t in occupied_boxes:
              if intersect := intersects(t, rect_bbox): break
            if not intersect:
              print(f"Placing signature field {iFieldCounter} in box on page {p}")
              occupied_boxes.append(rect_bbox)
              append_signature_field(w, SigFieldSpec(sig_field_name=f"Signature {iFieldCounter}", on_page=p, 
                box=[rect['x0'],rect['y0'],rect['x1'],rect['y1']]))
              iFieldCounter += 1
      w.write_in_place()
  return iFieldCounter

#----------------------------------

if __name__ == "__main__":
  main ()