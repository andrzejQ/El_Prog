// md-it.mjs
// Umieść w folderze `usr` poniżej `md-it.cmd`

import fs from 'fs';
import path from 'path';
// npm install -g  markdown-it markdown-it-attrs markdown-it-footnote markdown-it-anchor markdown-it-container markdown-it-prism
import MarkdownIt from 'markdown-it';
import markdownItTaskLists from 'markdown-it-task-lists';
import markdownItAttrs from 'markdown-it-attrs';
import markdownItFootnote from 'markdown-it-footnote';
import markdownItAnchor from 'markdown-it-anchor';
import markdownItPrism from 'markdown-it-prism';
//import markdownItContainer from 'markdown-it-container';

//console.log(process.argv) // Nazwa pliku z argumentów  
console.log(`ℹ️ node "${process.argv[1]}" "${process.argv[2]}" -> HTML`);

const pathMdItUsrObj = path.parse(process.argv[1]);
const dirMdIdUsr= pathMdItUsrObj.dir;                // 'C:\\nvm4w\\nodejs\\usr'
const pathMdIdUsr= dirMdIdUsr.replace(/\\/g, '/'); // 'C:/nvm4w/nodejs/usr' - dla href="/${pathMdIdUsr}/...
//console.log(pathMdItUsrObj); //{root: 'C:\\', dir: 'C:\\nvm4w\\nodejs\\usr', base: 'md-it.mjs', ext: '.mjs', name: 'md-it'}

const inputPath = process.argv[2];
if (!inputPath) {
  console.error('❌ Podaj ścieżkę do pliku Markdown jako argument.');
  process.exit(1);
}
// Wczytaj zawartość pliku
const mdContent = fs.readFileSync(inputPath, 'utf-8');

// konfiguracja markdown-it z wtyczkami
const md = new MarkdownIt({ html: true, linkify: true })
  .use(markdownItTaskLists)
  .use(markdownItAttrs)
  .use(markdownItFootnote)
  //.use(markdownItContainer, 'info')
  //.use(markdownItAnchor, 'level=[2, 3]')
  .use(markdownItAnchor)
  .use(markdownItPrism)

// MD -> HTML
const htmlMdIt = md.render(mdContent);

const fullHtml = 
`<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8">
  <title>${inputPath.base}</title>
<!-- Nagłówek lokalny - duplikat z wtyczki Markdown Viewer -->
<link rel="stylesheet" href="/${pathMdIdUsr}/css/plaintext.css">
<link rel="icon" href="/${pathMdIdUsr}/css/16x16.png">
<link rel="stylesheet" type="text/css" href="/${pathMdIdUsr}/css/github.css" id="_theme">
<link rel="stylesheet" type="text/css" href="/${pathMdIdUsr}/css/prism.min.css" id="_prism">
<link rel="stylesheet" href="/${pathMdIdUsr}/css/themes.css">
<link rel="stylesheet" href="/${pathMdIdUsr}/css/index.css">
</head>
<body class="_theme-github _color-light">
<div id="_html" class="markdown-body" style="visibility: visible;">

${htmlMdIt}

</div></body></html>
`
// Wynik do pliku .html

const outputPath = path.basename(inputPath, path.extname(inputPath)) + '.html';
fs.writeFileSync(outputPath, fullHtml, { encoding: "utf8" } );
console.log(`✅ Wygenerowano: ${outputPath}`);
