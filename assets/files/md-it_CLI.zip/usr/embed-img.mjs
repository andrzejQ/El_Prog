// embed-img.mjs
// Umieść w folderze `usr` poniżej `embed-img.cmd`

import fs from 'fs';
import path from 'path';
//import * as cheerio from 'cheerio';
import { load } from 'cheerio';
// npm install -g  cheerio

//console.log(process.argv) // Nazwa pliku z argumentów  
console.log(`ℹ️ node "${process.argv[1]}" "${process.argv[2]}" -> HTML(+img), tj. z wbudowanymi w HTML obrazami`);

const inputFile = process.argv[2];
if (!inputFile) {
  console.error('❌ Podaj ścieżkę do pliku HTML jako argument.');
  process.exit(1);
}
const outputFile = process.argv[3] || path.format({ ...path.parse(inputFile),
  base: undefined,            // wyczyść base, żeby nie nadpisywało
  ext: '+img.html'
});
// Wczytaj HTML
const html = fs.readFileSync(inputFile, 'utf8');
const $ = load(html); //cheerio
// Zamień <img src="..."> na data URI tylko dla lokalnych plików
$('img').each((_, el) => {
  const srcAttr = $(el).attr('src');
  if ( srcAttr &&
    !srcAttr.startsWith('data:') && !srcAttr.startsWith('http://') && !srcAttr.startsWith('https://')
  ) {
    try {
      const imgPath = path.resolve(path.dirname(inputFile), srcAttr);
      const ext = path.extname(imgPath).slice(1); // np. 'png'
      const data = fs.readFileSync(imgPath);
      const base64 = data.toString('base64');
      $(el).attr('src', `data:image/${ext};base64,${base64}`);
      console.log(`Osadzono obraz: ${srcAttr}`);
    } catch (err) {
      console.error(`❌ Nie udało się wczytać obrazu: ${srcAttr}`, err.message);
    }
  } else {
    console.log(`Pominięto obraz: ${srcAttr}`);
  }
});
console.log(`✅ Gotowy plik z wbudowanymi obrazami: ${outputFile}`);
fs.writeFileSync(outputFile, $.html(), 'utf8');
