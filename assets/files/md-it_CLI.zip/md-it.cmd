@set "dp0=%~dp0"
@node "%dp0%\usr\md-it.mjs" %1
