@set "dp0=%~dp0"
@node "%dp0%\usr\embed-img.mjs" %1
