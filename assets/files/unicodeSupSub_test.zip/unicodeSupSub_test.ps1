﻿Set-StrictMode -Version Latest

##########################################
# ˢᵘᵖᵉʳˢᶜʳⁱᵖᵗ and ₛᵤbₛcᵣᵢₚₜ in unicode text 
##########################################

[char[]]$unisup = ( "`0      `a`b`t`n`v`f`r                  " <#0..31#>  +
' !˝#ᙚ%&ˈ⁽⁾*⁺,⁻·/⁰¹²³⁴⁵⁶⁷⁸⁹:;<⁼>?@ᴬᴮCᴰᴱFᴳᴴᴵᴶᴷᴸᴹᴺᴼᴾQᴿSᵀᵁⱽᵂXYZ[\]^_`ᵃᵇᶜᵈᵉᶠᵍʰⁱʲᵏˡᵐⁿᵒᵖqʳˢᵗᵘᵛʷˣʸᶻ{|}˜' )

function USup {
  param( [string]$str )
  $r = ''
  foreach ($ch in [char[]]$str) {
    $r += if ($ch -cle '~') {$unisup[ [int][char]$ch ]} else {$ch}
  }
  $r
}

[char[]]$unisub = ( "`0      `a`b`t`n`v`f`r                  " <#0..31#>  +
' !˶#$%&˒₍₎*₊ˏ₋./₀₁₂₃₄₅₆₇₈₉:;<₌>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^ˍ˴abcdₑfgₕᵢⱼₖₗₘₙₒₚqᵣₛₜᵤᵥwₓᵧz{|}˷' )

function USub {
  param( [string]$str )
  $r = ''
  foreach ($ch in [char[]]$str) {
    $r += if ($ch -cle '~') {$unisub[ [int][char]$ch ]} else {$ch}
  }
  $r
}

USup "ABCabc 0`t1"
     #ᴬᴮCᵃᵇᶜ ⁰	¹
USup 590.6
    #⁵⁹⁰·⁶
USup ' !"#$%&''()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~ąćę'
     # !˝#ᙚ%&ˈ⁽⁾*⁺,⁻·/⁰¹²³⁴⁵⁶⁷⁸⁹:;<⁼>?@ᴬᴮCᴰᴱFᴳᴴᴵᴶᴷᴸᴹᴺᴼᴾQᴿSᵀᵁⱽᵂXYZ[\]^_`ᵃᵇᶜᵈᵉᶠᵍʰⁱʲᵏˡᵐⁿᵒᵖqʳˢᵗᵘᵛʷˣʸᶻ{|}˜ąćę

USub ' !"#$%&''()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~ąćę'
     # !˶#$%&˒₍₎*₊ˏ₋./₀₁₂₃₄₅₆₇₈₉:;<₌>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^ˍ˴abcdₑfgₕᵢⱼₖₗₘₙₒₚqᵣₛₜᵤᵥwₓᵧz{|}˷ąćę

<# Greek xᵝ ᵞ ᵟ ᵠ ᵡ ᶿ xᵦ ᵧ ᵨ ᵩ ᵪ
x ᶛ ᶜ ᶝ ᶞ ᶟ ᶠ ᶡ ᶢ ᶣ ᶤ ᶥ ᶦ ᶧ ᶨ ᶩ ᶪ ᶫ ᶬ ᶭ ᶮ ᶯ ᶰ ᶱ ᶲ ᶳ ᶴ ᶵ ᶶ ᶷ ᶸ ᶹ ᶺ ᶻ ᶼ ᶽ ᶾ
x ᘁ ᙆ ᙇ ᙚ ᙾ ᙿ ᣔ ᣕ ᣖ ᣗ ᣘ ᣙ ᣚ ᣛ ᣜ ᣝ ᣞ ᣟ ᣳ ᣴ ᣵ ᐧ xᕀ ᕁ #>