import json 
import csv
from collections import namedtuple
''''
Po wyszukaniu kanałów w programie LiveTV - Android TV
powstaje plik "\backup_user_databases\TvProviderChannels\tv_provider_db.json",
z aktualną informacją o dostępnych kanałach DVB-T/T2 - wynik w "andrTVchInfo.csv"
- tj. płaski JSON z rozbudowaną wartością "internal_provider_data", jako 
literał (str) słownika "custom"
'''
# andr_tv_chn_db.py uruchomiony w folderze \backup_user_databases\TvProviderChannels\
tv_provider_db_json = 'tv_provider_db.json'
andr_tv_chng_nr_csv = 'andr_tv_chng_nr.csv'
'''
Pobranie danych z nową numeracją "andr_tv_chng_nr.csv", np.
display_name;S_internal_provider_data;internal_provider_flag4;browsable
"TVN24 BiS";;161
TVP ABC;538000000;777;
TVP ABC;;182;0

W kolumnie S_<klucz> jest opcjonalnie napis do poszukania w wartości <klucz>, np. częstotliwość kanału
Gdy dane w tej kol. to powinny być wyżej w CSV, wtedy inne dane z tą samą nazwą dotyczą innej częstotliwości

Dalej (internal_provider_flag4;browsable) mamy listę kluczy do podmieniania wartości (gdy nie-puste).
Uwaga - internal_provider_flag4 = nr_kanału-1
'''

with open(tv_provider_db_json, 'r', encoding='utf-8') as fj:
  data_json = json.load(fj) 
print(len(data_json),'kanałów')

with open(andr_tv_chng_nr_csv, newline='', encoding='utf-8-sig') as csvF:
  reader = csv.reader(csvF, delimiter=';')
  nTuple = namedtuple('nTuple', next(reader))  # get names from column headers
  print(f'''{nTuple._fields=}''') #$#  ('display_name', 'S_internal_provider_data', 'internal_provider_flag4', 'browsable')
  arr = [ nTuple._make((row+['']*4)[:len(nTuple._fields)]) for row in reader ] # [:len()... korekcja dłuższej listy 
  # [nTuple(display_name='TVN24 BiS', S_internal_provider_data='', internal_provider_flag4='161', browsable=''), ...
  
# nazwa może być zduplikowana - np. dla innych częstotl. Dlatego lista zestawów (dict) danych (zwykle 1-elem.)
di_name_ch_nr = {}
name = nTuple._fields[0] # 'display_name'
strIn = nTuple._fields[1][2:] # 'internal_provider_data'
for a in arr:
  ch_inf = { 'subStr':a[1], 'updt': {k: (int(v) if v.isdigit() else v)
    for k, v in a._asdict().items() if v and not (k in nTuple._fields[:2])} } # pomija puste v i kolumny [:2]
  # np. {'subStr': '', 'updt': {'internal_provider_flag4': 182, 'browsable': 0}}
  di_name_ch_nr.setdefault(a[0], []).append(ch_inf)
    
#print(f'''\n{di_name_ch_nr=}\n''') # {
# 'TVN24 BiS HD': [{'subStr': '', 'updt': {'internal_provider_flag4': 161}}],
# 'TVP ABC': [{'subStr': '538000000', 'updt': {'internal_provider_flag4': 777}}, 
#             {'subStr': '', 'updt': {'internal_provider_flag4': 182, 'browsable': 0}}]
# }

for ch_data in data_json:
  nm = ch_data.get(name,'') #$# if nm.startswith('TV'): print(f'''\t\t{nm=}''')
  for ch_updt in di_name_ch_nr.get( nm,[] ): #zwykle 1 zestaw, ale czasem więcej
    if not ch_updt.get('subStr') or ( ch_updt.get('subStr') in ch_data.get(strIn,'') ):
      ch_data.update(ch_updt.get('updt',''))
      print(f'''{nm} -> {ch_updt=}''')
      break;
  
with open(r'tv_prov.json ', 'w', encoding='utf-8') as fj:
  fj.write(json.dumps(data_json, ensure_ascii=False ,separators=(',', ':')).replace(r'/',r'\/'))

