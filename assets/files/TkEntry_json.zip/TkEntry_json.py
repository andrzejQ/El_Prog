#!/usr/bin/python3 -i
from TkEntryWidget import tkForm
import json 
try: # ordered dict py 3.7+
  with open('conf_0.json', 'r', encoding='utf-8') as fj: 
    di = json.load(fj) 
except FileNotFoundError:
  di = {'Imię':'Iii', 'Imię 2': 'iii 2', 'Nazwisko': 'Nnn'}

di = tkForm( di )
print(di)

if di: # tj. gdy [OK] a nie [Esc]
  with open('conf_0.json', 'w', encoding='utf-8') as fj:
    json.dump(di, fj, ensure_ascii=False, indent=2)
