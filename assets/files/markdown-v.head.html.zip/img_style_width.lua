-- pandoc --lua-filter for markdown size attributes as {style="width:... instead of {width="...
-- written by novice pandoc user - don't rely too much on it
if FORMAT:match 'markdown' then
  function Image(el)
    el.attributes.style = (el.attributes.style or '') .. 
      ' width:' ..   (el.attributes.width or 'auto') .. 
      '; height:' .. (el.attributes.height or 'auto') .. ';'
    el.attributes.width = nil
    el.attributes.height = nil
    return el
  end
end
