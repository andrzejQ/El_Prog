// ==UserScript==
// @name         Wstawiaj kolejne paczki danych
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  ...
// @author       AK
// @match        https://WWWzFormularzem*
// @match        file:///*/FormTest-Wstaw-kolejne-paczki-danych.html*
// @grant        none
// ==/UserScript==

//gdy tampermonkey pokazuje podwójną liczbę dopasowanych skryptów:
if (window.top !== window.self)	return; // Don’t run in frames.
// https://www.tampermonkey.net/
/************************************
* 2022-10-17
* lista1 to łańcuch wielowierszowy - pola są oddzielone \t (tekstowa kopia z Excela)
* Uwaga pierwszy i ostatni wiersz jest pusty (zob. let lista1=` i `;...).
* Początkowy wiersz danych to zrozumiałe dla człowieka nazwy, a drugi wiersz to atrybut "name" albo "id" poprzedzone "#".
* Checkbox i Radio (id)  jest klikany, gdy 'x'/brak nie zgadza się ze stanem pola
* Podobnie Radio gdy podano name i value
* 
* Po odświeżeniu strony zatwierdź dane do seryjnego wypełniania.
* Po tym pojawia się przycisk dla kolejnej paczki danych do wypełnienia
* Po jego kliknięciu otrzymujemy wypełniony formularz - można wysłać dane, albo je zignorować. Równocześnie przycisk pokazuje dane z kolejnego wiersza, które zostaną podstawione po jego kliknięciu. Można go klikać dowolną liczbę razy - w formularzu będą się pojawiały kolejne paczki danych.
*/

(function() {
    'use strict';
    // your code here

// Poniżej jest kopia tekstu z Excela. Nie można używać ręcznego łamania wiersza w komórce [Alt+Enter].

let lista1=`
Pole tekstowe	Obszar tekstowy	Lista1 - rozwijana	Lista - wielokrotny wybór	Pole wyboru	Opcja 1	Opcja 2	Opcja 3	Opcje2 wg. wartości	Wywołaj funkcję JS
textbox	textarea	selectDropdown	selectMultiple	checkbox	#radioSel1	#radioSel2	#radioSel3	radioSelect2Nm	new Function()()
Pierwszy wiersz arkusza	to przyjazne nazwy danych - będzie ignorowany.	s 3	multiVal 2	x		x		rdVal 3	console.log('tinymce.activeEditor.setContent("Gdy w formularzu jest jeden edytor Tiny MCE,");')
Drugi wiersz to	albo "name" pól formularza, albo ich "id" - poprzedzone "#"	s 1	multiVal 3		x			rdVal 1	console.log('tinymce.activeEditor.setContent("to tak można się do niego odwołać.");')
Gdy pole "radio" jest wskazywane przez "id",	to wstawiasz "x" dla wyboru, lub <nic> aby odznaczyć 	s 1	multiVal 3	x		x		rdVal 3	
x lub brak oznacza "zaznacz" lub "odznacz"	i powoduje kliknięcie na elemencie, gdy stan elementu jest inny niż wpisany/brakujący "x".	s 3	multiVal 1		x			rdVal 1	
Gdy pole "radio" jest wskazywane przez "name",	to wstawiasz wartość "value", która ma być wybrana.	s 1	multiVal 3	x		x		rdVal 3	
 Aby wywołać funkcję javascript	w nagłówku w 2-gim wierszu wpisz "new Function()()", a w danych  - treść funkcji.	s 3	multiVal 1		x			rdVal 1	
Całość arkusza skopiuj	z pomocą edytora tekstowego do pliku "Zapisz dane do localStorage.user.js" powyżej ostatniego wiersza, poniżej wiersza "let lista1=". Wygodnie jest używać wtyczki https://www.tampermonkey.net/								
Łamanie wiersza w komórce Excela	[Alt+Enter] nie jest obecnie możliwe (tzn. nie jest oprogramowane). Nie można też nigdzie używać odwrotnego apostrofu.								
`; 

const formSel = '[name="form1"]'; // selektor obszaru dla formy do wstawiania danych -> querySelector(), np. div, form, ...

    let nrPocz = 0;
    let nrNast = sessionStorage.getItem("nrNast"); //od tego numeru zaczynamy wypełnianie po odświeżeniu strony.
    if (!(null === nrNast)) {nrPocz = parseInt(nrNast); if (nrPocz < 0) {nrPocz = 0}};

    const PrzygotujListe = `Przygotuj kolejny wiersz -> ${nrPocz+1}`
    const btn0 = document.createElement("button");
    btn0.id = "wklejaj-dane"; btn0.innerHTML = PrzygotujListe;
    btn0.setAttribute.type = "button"; btn0.style.backgroundColor="LightCyan"; btn0.style.height = '33px';
    document.body.prepend(btn0); 

    const btn1 = document.createElement("button");
    btn1.id = "zobacz-dane"; btn1.innerHTML = "Zobacz dane do wstawiania";
    btn1.setAttribute.type = "button"; btn1.style.backgroundColor="LightCyan"; btn1.style.height = '33px';
    btn1.onclick = function(){wczytajDane(lista1); alert(listaStr);};
    document.body.prepend(btn1); 


    let listaStr='', naglowekPL, header2, daneFormularza; //ustawiane jednorazowo po wywołaniu:
    function wczytajDane(lista1) {
        if (listaStr!=='') return; //>>>>>>>>>
        listaStr="Przygotowane dane:\n"
        let d = lista1.split("\n")
        d.pop(); d.shift(); //  console.log(d); - pierwszy i ostatni wiersz jest pusty
        naglowekPL = d.shift();     //console.log(naglowekPL);-nagłówek z czytelnymi tytułami kolumn (ignorowany)
        naglowekPL = naglowekPL.split('\t');    //console.log(naglowekPL);
        header2 = d.shift();   //console.log(header2); - nagłówek name/#id pól
        header2 = header2.split('\t');    //console.log(header2);
        //console.log('dane:\n',d)
        daneFormularza = []; //kolejne wiersze danych odpowiadające nagłówkowi
        for (let i=0; i<d.length; i++) {
            let r = d[i].split('\t');
            daneFormularza.push(r);
        }
        console.log('\n------ Przygotowanie danych -------')
        for (let i=0; i<daneFormularza.length; i++) {
            listaStr += lp_fragmentDanych(i, daneFormularza[i])+"\n"
        }
    }
    
    function lp_fragmentDanych(lp, a) {return ''+(1+lp)+'. '+(a||[]).join(' -|- ').substring(0, 64);}

    let stan = -1; //Przygotuj kolejny wiersz, 0, 1,...
    
    console.log('formSel: ',formSel, '          nrPocz: ',nrPocz)
    var form1 = document.querySelector(formSel)
    if (! form1) alert(`Uwaga! - na tej stronie nie ma obszaru: querySelector("${formSel}")`);

    btn0.addEventListener ("click", function() {

        wczytajDane(lista1);
        if (stan < 0){ //start
            // alert(listaStr); //przeniesione do przycisku "Zobacz dane..."
            console.log('\n------ wpis dla kolejnych danych -------')
            stan = nrPocz;
            btn0.innerHTML = lp_fragmentDanych(stan, daneFormularza[stan]); console.log(btn0.innerHTML);
            btn0.style.backgroundColor="Cyan";
        } /*-1*/
        else { //stan: 0, 1, ....
            if (stan >= daneFormularza.length){
                stan = -1
                btn0.innerHTML = 'Znowu(?) '+PrzygotujListe;
                btn0.style.backgroundColor="LightCyan";
            }
            else {
                //if (!(document.querySelector('....'))) alert('Uwaga! - brak formularza);
                let dF = daneFormularza[stan];
                for (let k=0; k<header2.length; k++) {
                    let _isId = 0 //typ selektora w kol.
                    let elem = header2[k]
                    let val  = dF[k]
                    if (! elem) {continue} // >>>>>>>>>>>>>>>>>
                    let inp = null;
                    if (elem == "new Function()()") {
                        if (val) {new Function(val)();}
                        continue // >>>>>>>>>>>>>>>>>
                    } else if ( "#" == elem.substring(0, 1)) {
                        //elem = elem.substring(1)  //inp = document.getElementById(elem); 
                        inp = form1.querySelector(elem);
                        _isId = 1
                    } else {
                        //inp = document.getElementsByName(elem)[0]
                        inp = form1.querySelector(`[name="${elem}"]`);
                    }
                    if (inp) {
                        let inp_type = '';
                        if (typeof inp.type == 'string') {
                            inp_type = inp.type.toLowerCase();
                        }
                        if ((inp_type=="radio") && (! _isId)) {
                            if (! val) continue; // >>>>>>>>>>>>>>>>>
                            //inp = document.querySelector(`input[name="${elem}"][value="${val}"]`)
                            inp = form1.querySelector(`input[name="${elem}"][value="${val}"]`)
                            val = 'x'
                        }
                        if ( (inp) && ((inp_type=="checkbox") || (inp_type=="radio")) ) {
                            //checkbox i radio jest klikany, gdy nie pasuje do x/brak
                            let setChecked = (val=='x');
                            if (setChecked != inp.checked) {
                                inp.click();
                            }
                        } else if ( (inp) && ('value' in inp) ) {//dla <input>, <textArea>, <select>
                            inp.value = val;
                        }
                        else {
                            let warn = `Uwaga: Nie rozpoznany rodzaj pola "${header2[k]}". Nie podstawiono wartości: "${dF[k]}"`;
                            console.warn(warn);
                            alert(warn);
                        }
                    } //if (inp)
                    if (! inp) {
                        console.warn(`Nie odnaleziono pola "${header2[k]}". Nie użyto wartości: "${dF[k]}"`);
                    }
                } //for
                stan++;
                if (stan < daneFormularza.length){
                    btn0.innerHTML = `<b>${stan}.</b> , nast.: `+lp_fragmentDanych(stan, daneFormularza[stan]);
                    btn0.style.backgroundColor="LightSkyBlue";
                }
                else {
                    btn0.innerHTML = 'KONIEC.';
                    btn0.style.backgroundColor="LightCyan";
                    stan = 0;
                }
                sessionStorage.setItem("nrNast", stan);  //trwałe zapamiętanie nast.nru - gdyby wysłanie formularza odświeżało stronę
                console.log(btn0.innerHTML);

            }
        }
    });
})();
