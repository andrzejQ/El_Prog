// ==UserScript==
// @name         Wstawiaj kolejne paczki danych
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  ...
// @author       AK
// @match        https://WWWzFormularzem*
// @match        file:///*/FormTest-Wstaw-kolejne-paczki-danych.html
// @grant        none
// ==/UserScript==

// https://www.tampermonkey.net/
/************************************
* 2022-10-17
* Po odświeżeniu strony zatwierdź dane do seryjnego wypełniania.
* Po tym pojawia się przycisk dla kolejnej paczki danych do wypełnienia
* Po jego kliknięciu otrzymujemy wypełniony formularz - można wysłać dane, albo je zignorować.
* Można klikać dowolną liczbę razy - w formularzu będą się pojawiały kolejne paczki danych.
*/
(function() {
    'use strict';
    // your code here

    const btn0 = document.createElement("button");
    const PrzygotujListe = "Zobacz dane do wstawiania..."
    btn0.id = "wklejaj-dane"; btn0.innerHTML = PrzygotujListe;
    btn0.setAttribute.type = "button"; btn0.style.position = "fixed";
    btn0.style.height = '33px'; btn0.style.top = '10px'; btn0.style.left = '222px';
    document.body.appendChild(btn0);

    function lp_fragmentDanych(lp, a) {return ''+(1+lp)+'. '+a.join(' -|- ').substring(0, 64);}

    let stan = -1; //"Zobacz dane..."; 0, 1
    let nrPocz = 0;

    btn0.addEventListener ("click", function() {
        let nrPocz1 = sessionStorage.getItem("nrPocz1");
        if (!(null === nrPocz1)) {nrPocz = parseInt(nrPocz1)-1; if (nrPocz < 0) {nrPocz = 0}};


        let lista1 = sessionStorage.getItem("lista1");
        let d = lista1.split("\n")
        d.pop(); d.shift(); //  console.log(d); - pierwszy i ostatni wiersz jest pusty
        let naglowekPL = d.shift();     //console.log(naglowekPL);-nagłówek z czytelnymi tytułami kolumn (ignorowany)
        naglowekPL = naglowekPL.split('\t');    //console.log(naglowekPL);
        let header2 = d.shift();   //console.log(header2); - nagłówek name/#id pól
        header2 = header2.split('\t');    //console.log(header2);
        //console.log('dane:\n',d)
        let daneFormularza = []; //kolejne wiersze danych odpowiadające nagłówkowi
        for (let i=0; i<d.length; i++) {
            let dF = {};
            let r = d[i].split('\t');
            daneFormularza.push(r);
        }

        if (stan < 0){
            console.log('\n------ Przygotowanie danych -------')
            let listaStr="Przygotowane dane:\n"
            for (let i=0; i<daneFormularza.length; i++) {
                listaStr += lp_fragmentDanych(i, daneFormularza[i])+"\n"
            }
            alert(listaStr);
            console.log('\n------ wpis dla kolejnych danych -------')
            stan = nrPocz;
            btn0.innerHTML = lp_fragmentDanych(stan, daneFormularza[stan]); console.log(btn0.innerHTML);
        } /*-1*/
        else { // 0, 1, ....
            if (stan >= daneFormularza.length){
                stan = -1
                btn0.innerHTML = 'Znowu(?) '+PrzygotujListe;
            }
            else {
                //if (!(document.querySelector('....'))) alert('Uwaga! - brak formularza);
                let dF = daneFormularza[stan];
                for (let k=0; k<header2.length; k++) {
                    let _isId = 0 //typ selektora w kol.
                    let elem = header2[k]
                    let val  = dF[k]
                    if (! elem) {continue} // >>>>>>>>>>>>>>>>>
                    let inp = null;
                    if (elem == "new Function()()") {
                        if (val) {new Function(val)();}
                        continue // >>>>>>>>>>>>>>>>>
                    } else if ( "#" == elem.substring(0, 1)) {
                        elem = elem.substring(1)
                        inp = document.getElementById(elem);
                        _isId = 1
                    } else {
                        inp = document.getElementsByName(elem)[0]
                    }
                    if (inp) {
                        let inp_type = '';
                        if (typeof inp.type == 'string') {
                            inp_type = inp.type.toLowerCase();
                        }
                        if ((inp_type=="radio") && (! _isId)) {
                            if (! val) continue; // >>>>>>>>>>>>>>>>>
                            inp = document.querySelector(`input[name="${elem}"][value="${val}"]`)
                            val = 'x'
                        }
                        if ( (inp) && ((inp_type=="checkbox") || (inp_type=="radio")) ) {
                            //checkbox i radio jest klikany, gdy nie pasuje do x/brak
                            let setChecked = (val=='x');
                            if (setChecked != inp.checked) {
                                inp.click();
                            }
                        } else if ( (inp) && ('value' in inp) ) {//dla <input>, <textArea>, <select>
                            inp.value = val;
                        }
                        else {
                            let warn = `Uwaga: Nie rozpoznany rodzaj pola "${header2[k]}". Nie podstawiono wartości: "${dF[k]}"`;
                            console.warn(warn);
                            alert(warn);
                        }
                    } //if (inp)
                    if (! inp) {
                        console.warn(`Nie odnaleziono pola "${header2[k]}". Nie użyto wartości: "${dF[k]}"`);
                    }
                } //for
                stan++;
                if (stan < daneFormularza.length){
                    btn0.innerHTML = lp_fragmentDanych(stan, daneFormularza[stan]);
                }
                else {
                    btn0.innerHTML = 'KONIEC.';
                }
                console.log(btn0.innerHTML);

            }
        }
    });
})();
