// ==UserScript==
// @name         Zapisz dane do localStorage.user
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  ...
// @author       AK
// @match        https://WWWzFormularzem*
// @match        file:///*/FormTest-Wstaw-kolejne-paczki-danych.html*
// @grant        none
// ==/UserScript==

// https://www.tampermonkey.net/
/************************************
* 2022-10-
* Zapisuje listę do localStorage po napotkaniu stron @match j.w.
* jako 1 łańcuch wielowierszowy - pola oddzielone \t (tekstowa kopia z Excela)
* Uwaga pierwszy i ostatni wiersz jest pusty (zob. let lista1=` i `;...).
* Początkowy wiersz danych to zrozumiałe dla człowieka nazwy, a drugi wiersz to atrybut "name" albo "id" poprzedzone "#".
* Checkbox i Radio (id)  jest klikany, gdy 'x'/brak nie zgadza się ze stanem pola
* Podobnie Radio gdy podano name i value
*/
(function() {
	'use strict';
	// your code here
sessionStorage.setItem("formSel", '[name="form1"]' ); // selektor obszaru dla formy do wstawiania danych -> querySelector(), np. div, form, ...
sessionStorage.setItem("nrPocz1", 1);  //od tego numeru zaczynamy wypełnianie (1, 2, ...)
// Poniżej jest kopia tekstu z Excela. Nie można używać ręcznego łamania wiersza w komórce [Alt+Enter].

let lista1=`
Pole tekstowe	Obszar tekstowy	Lista1 - rozwijana	Lista - wielokrotny wybór	Pole wyboru	Opcja 1	Opcja 2	Opcja 3	Opcje2 wg. wartości	Wywołaj funkcję JS
textbox	textarea	selectDropdown	selectMultiple	checkbox	#radioSel1	#radioSel2	#radioSel3	radioSelect2Nm	new Function()()
Pierwszy wiersz arkusza	to przyjazne nazwy danych - będzie ignorowany.	s 3	multiVal 2	x		x		rdVal 3	console.log('tinymce.activeEditor.setContent("Gdy w formularzu jest jeden edytor Tiny MCE,");')
Drugi wiersz to	albo "name" pól formularza, albo ich "id" - poprzedzone "#"	s 1	multiVal 3		x			rdVal 1	console.log('tinymce.activeEditor.setContent("to tak można się do niego odwołać.");')
Gdy pole "radio" jest wskazywane przez "id",	to wstawiasz "x" dla wyboru, lub <nic> aby odznaczyć 	s 1	multiVal 3	x		x		rdVal 3	
x lub brak oznacza "zaznacz" lub "odznacz"	i powoduje kliknięcie na elemencie, gdy stan elementu jest inny niż wpisany/brakujący "x".	s 3	multiVal 1		x			rdVal 1	
Gdy pole "radio" jest wskazywane przez "name",	to wstawiasz wartość "value", która ma być wybrana.	s 1	multiVal 3	x		x		rdVal 3	
 Aby wywołać funkcję javascript	w nagłówku w 2-gim wierszu wpisz "new Function()()", a w danych  - treść funkcji.	s 3	multiVal 1		x			rdVal 1	
Całość arkusza skopiuj	z pomocą edytora tekstowego do pliku "Zapisz dane do localStorage.user.js" powyżej ostatniego wiersza, poniżej wiersza "let lista1=". Wygodnie jest używać wtyczki https://www.tampermonkey.net/								
Łamanie wiersza w komórce Excela	[Alt+Enter] nie jest obecnie możliwe (tzn. nie jest oprogramowane). Nie można też nigdzie używać odwrotnego apostrofu.								
`; sessionStorage.setItem("lista1", lista1);})();
